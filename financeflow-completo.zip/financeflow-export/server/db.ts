import { and, desc, eq, gte, lte, like, sql, sum } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  users, categories, transactions, budgets, goals,
  InsertUser, InsertCategory, InsertTransaction, InsertBudget, InsertGoal,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ── Users ──────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    const value = user[field];
    if (value === undefined) continue;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function updateUserProfile(userId: number, data: Partial<InsertUser>) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set(data).where(eq(users.id, userId));
}

// ── Categories ─────────────────────────────────────────────────────────────
export async function getCategoriesByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(categories).where(eq(categories.userId, userId));
}

export async function createCategory(data: InsertCategory) {
  const db = await getDb();
  if (!db) return;
  const result = await db.insert(categories).values(data);
  return result;
}

export async function updateCategory(id: number, userId: number, data: Partial<InsertCategory>) {
  const db = await getDb();
  if (!db) return;
  await db.update(categories).set(data).where(and(eq(categories.id, id), eq(categories.userId, userId)));
}

export async function deleteCategory(id: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(categories).where(and(eq(categories.id, id), eq(categories.userId, userId)));
}

export async function seedDefaultCategories(userId: number) {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select().from(categories).where(and(eq(categories.userId, userId), eq(categories.isDefault, true))).limit(1);
  if (existing.length > 0) return;

  const defaults: InsertCategory[] = [
    { userId, name: "Alimentação", icon: "utensils", color: "#F59E0B", type: "expense", isDefault: true },
    { userId, name: "Transporte", icon: "car", color: "#3B82F6", type: "expense", isDefault: true },
    { userId, name: "Moradia", icon: "home", color: "#8B5CF6", type: "expense", isDefault: true },
    { userId, name: "Saúde", icon: "heart", color: "#EF4444", type: "expense", isDefault: true },
    { userId, name: "Lazer", icon: "gamepad-2", color: "#EC4899", type: "expense", isDefault: true },
    { userId, name: "Educação", icon: "book-open", color: "#06B6D4", type: "expense", isDefault: true },
    { userId, name: "Compras", icon: "shopping-bag", color: "#F97316", type: "expense", isDefault: true },
    { userId, name: "Salário", icon: "briefcase", color: "#10B981", type: "income", isDefault: true },
    { userId, name: "Freelance", icon: "laptop", color: "#6366F1", type: "income", isDefault: true },
    { userId, name: "Investimentos", icon: "trending-up", color: "#14B8A6", type: "income", isDefault: true },
    { userId, name: "Outros", icon: "more-horizontal", color: "#6B7280", type: "both", isDefault: true },
  ];
  await db.insert(categories).values(defaults);
}

// ── Transactions ───────────────────────────────────────────────────────────
export async function getTransactions(
  userId: number,
  opts: {
    limit?: number;
    offset?: number;
    type?: "income" | "expense";
    categoryId?: number;
    search?: string;
    startDate?: Date;
    endDate?: Date;
  } = {}
) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };

  const conditions = [eq(transactions.userId, userId)];
  if (opts.type) conditions.push(eq(transactions.type, opts.type));
  if (opts.categoryId) conditions.push(eq(transactions.categoryId, opts.categoryId));
  if (opts.search) conditions.push(like(transactions.description, `%${opts.search}%`));
  if (opts.startDate) conditions.push(gte(transactions.date, opts.startDate));
  if (opts.endDate) conditions.push(lte(transactions.date, opts.endDate));

  const where = and(...conditions);

  const [items, countResult] = await Promise.all([
    db
      .select({
        id: transactions.id,
        userId: transactions.userId,
        categoryId: transactions.categoryId,
        type: transactions.type,
        amount: transactions.amount,
        description: transactions.description,
        notes: transactions.notes,
        receiptUrl: transactions.receiptUrl,
        date: transactions.date,
        isRecurring: transactions.isRecurring,
        recurringInterval: transactions.recurringInterval,
        tags: transactions.tags,
        createdAt: transactions.createdAt,
        categoryName: categories.name,
        categoryIcon: categories.icon,
        categoryColor: categories.color,
      })
      .from(transactions)
      .leftJoin(categories, eq(transactions.categoryId, categories.id))
      .where(where)
      .orderBy(desc(transactions.date))
      .limit(opts.limit ?? 50)
      .offset(opts.offset ?? 0),
    db.select({ count: sql<number>`count(*)` }).from(transactions).where(where),
  ]);

  return { items, total: Number(countResult[0]?.count ?? 0) };
}

export async function getTransactionById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(transactions).where(and(eq(transactions.id, id), eq(transactions.userId, userId))).limit(1);
  return result[0];
}

export async function createTransaction(data: InsertTransaction) {
  const db = await getDb();
  if (!db) return;
  const result = await db.insert(transactions).values(data);
  return result;
}

export async function updateTransaction(id: number, userId: number, data: Partial<InsertTransaction>) {
  const db = await getDb();
  if (!db) return;
  await db.update(transactions).set({ ...data, updatedAt: new Date() }).where(and(eq(transactions.id, id), eq(transactions.userId, userId)));
}

export async function deleteTransaction(id: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(transactions).where(and(eq(transactions.id, id), eq(transactions.userId, userId)));
}

export async function getFinancialSummary(userId: number, startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return { income: 0, expense: 0, balance: 0 };

  const result = await db
    .select({
      type: transactions.type,
      total: sum(transactions.amount),
    })
    .from(transactions)
    .where(and(eq(transactions.userId, userId), gte(transactions.date, startDate), lte(transactions.date, endDate)))
    .groupBy(transactions.type);

  let income = 0;
  let expense = 0;
  for (const row of result) {
    if (row.type === "income") income = Number(row.total ?? 0);
    if (row.type === "expense") expense = Number(row.total ?? 0);
  }
  return { income, expense, balance: income - expense };
}

export async function getSpendingByCategory(userId: number, startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select({
      categoryId: transactions.categoryId,
      categoryName: categories.name,
      categoryIcon: categories.icon,
      categoryColor: categories.color,
      total: sum(transactions.amount),
      count: sql<number>`count(*)`,
    })
    .from(transactions)
    .leftJoin(categories, eq(transactions.categoryId, categories.id))
    .where(and(eq(transactions.userId, userId), eq(transactions.type, "expense"), gte(transactions.date, startDate), lte(transactions.date, endDate)))
    .groupBy(transactions.categoryId, categories.name, categories.icon, categories.color)
    .orderBy(desc(sum(transactions.amount)));
}

export async function getMonthlyComparison(userId: number, months: number = 6) {
  const db = await getDb();
  if (!db) return [];

  const startDate = new Date();
  startDate.setMonth(startDate.getMonth() - months + 1);
  startDate.setDate(1);
  startDate.setHours(0, 0, 0, 0);

  return db
    .select({
      month: sql<string>`DATE_FORMAT(${transactions.date}, '%Y-%m')`,
      type: transactions.type,
      total: sum(transactions.amount),
    })
    .from(transactions)
    .where(and(eq(transactions.userId, userId), gte(transactions.date, startDate)))
    .groupBy(sql`DATE_FORMAT(${transactions.date}, '%Y-%m')`, transactions.type)
    .orderBy(sql`DATE_FORMAT(${transactions.date}, '%Y-%m')`);
}

// ── Budgets ────────────────────────────────────────────────────────────────
export async function getBudgets(userId: number, month: number, year: number) {
  const db = await getDb();
  if (!db) return [];

  const budgetList = await db
    .select({
      id: budgets.id,
      userId: budgets.userId,
      categoryId: budgets.categoryId,
      name: budgets.name,
      limitAmount: budgets.limitAmount,
      period: budgets.period,
      alertThreshold: budgets.alertThreshold,
      alertEnabled: budgets.alertEnabled,
      month: budgets.month,
      year: budgets.year,
      categoryName: categories.name,
      categoryIcon: categories.icon,
      categoryColor: categories.color,
    })
    .from(budgets)
    .leftJoin(categories, eq(budgets.categoryId, categories.id))
    .where(and(eq(budgets.userId, userId), eq(budgets.month, month), eq(budgets.year, year)));

  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0, 23, 59, 59);

  const enriched = await Promise.all(
    budgetList.map(async (b) => {
      const conditions = [eq(transactions.userId, userId), eq(transactions.type, "expense"), gte(transactions.date, startDate), lte(transactions.date, endDate)];
      if (b.categoryId) conditions.push(eq(transactions.categoryId, b.categoryId));

      const spentResult = await db
        .select({ total: sum(transactions.amount) })
        .from(transactions)
        .where(and(...conditions));

      const spent = Number(spentResult[0]?.total ?? 0);
      const limit = Number(b.limitAmount);
      return { ...b, spent, percentage: limit > 0 ? Math.min((spent / limit) * 100, 100) : 0 };
    })
  );

  return enriched;
}

export async function createBudget(data: InsertBudget) {
  const db = await getDb();
  if (!db) return;
  await db.insert(budgets).values(data);
}

export async function updateBudget(id: number, userId: number, data: Partial<InsertBudget>) {
  const db = await getDb();
  if (!db) return;
  await db.update(budgets).set(data).where(and(eq(budgets.id, id), eq(budgets.userId, userId)));
}

export async function deleteBudget(id: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(budgets).where(and(eq(budgets.id, id), eq(budgets.userId, userId)));
}

// ── Goals ──────────────────────────────────────────────────────────────────
export async function getGoals(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(goals).where(eq(goals.userId, userId)).orderBy(desc(goals.createdAt));
}

export async function createGoal(data: InsertGoal) {
  const db = await getDb();
  if (!db) return;
  await db.insert(goals).values(data);
}

export async function updateGoal(id: number, userId: number, data: Partial<InsertGoal>) {
  const db = await getDb();
  if (!db) return;
  await db.update(goals).set({ ...data, updatedAt: new Date() }).where(and(eq(goals.id, id), eq(goals.userId, userId)));
}

export async function deleteGoal(id: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(goals).where(and(eq(goals.id, id), eq(goals.userId, userId)));
}
