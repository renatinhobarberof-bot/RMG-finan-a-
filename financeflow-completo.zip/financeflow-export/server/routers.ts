import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { storagePut } from "./storage";
import {
  upsertUser, getUserByOpenId, updateUserProfile,
  getCategoriesByUser, createCategory, updateCategory, deleteCategory, seedDefaultCategories,
  getTransactions, getTransactionById, createTransaction, updateTransaction, deleteTransaction,
  getFinancialSummary, getSpendingByCategory, getMonthlyComparison,
  getBudgets, createBudget, updateBudget, deleteBudget,
  getGoals, createGoal, updateGoal, deleteGoal,
} from "./db";

// ── Auth Router ────────────────────────────────────────────────────────────
const authRouter = router({
  me: publicProcedure.query((opts) => opts.ctx.user),
  logout: publicProcedure.mutation(({ ctx }) => {
    const cookieOptions = getSessionCookieOptions(ctx.req);
    ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    return { success: true } as const;
  }),
  updateProfile: protectedProcedure
    .input(z.object({
      name: z.string().min(1).max(100).optional(),
      currency: z.string().max(8).optional(),
      theme: z.enum(["dark", "light", "system"]).optional(),
      notificationsEnabled: z.boolean().optional(),
      biometricEnabled: z.boolean().optional(),
      onboardingCompleted: z.boolean().optional(),
      avatarUrl: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      await updateUserProfile(ctx.user.id, input);
      return { success: true };
    }),
  uploadAvatar: protectedProcedure
    .input(z.object({ base64: z.string(), mimeType: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const buffer = Buffer.from(input.base64, "base64");
      const key = `avatars/${ctx.user.id}-${Date.now()}.jpg`;
      const { url } = await storagePut(key, buffer, input.mimeType);
      await updateUserProfile(ctx.user.id, { avatarUrl: url });
      return { url };
    }),
});

// ── Categories Router ──────────────────────────────────────────────────────
const categoriesRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    await seedDefaultCategories(ctx.user.id);
    return getCategoriesByUser(ctx.user.id);
  }),
  create: protectedProcedure
    .input(z.object({
      name: z.string().min(1).max(100),
      icon: z.string().default("circle"),
      color: z.string().default("#8B5CF6"),
      type: z.enum(["income", "expense", "both"]).default("both"),
    }))
    .mutation(async ({ ctx, input }) => {
      await createCategory({ ...input, userId: ctx.user.id, isDefault: false });
      return { success: true };
    }),
  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      name: z.string().min(1).max(100).optional(),
      icon: z.string().optional(),
      color: z.string().optional(),
      type: z.enum(["income", "expense", "both"]).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      await updateCategory(id, ctx.user.id, data);
      return { success: true };
    }),
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await deleteCategory(input.id, ctx.user.id);
      return { success: true };
    }),
});

// ── Transactions Router ────────────────────────────────────────────────────
const transactionsRouter = router({
  list: protectedProcedure
    .input(z.object({
      limit: z.number().min(1).max(100).default(20),
      offset: z.number().min(0).default(0),
      type: z.enum(["income", "expense"]).optional(),
      categoryId: z.number().optional(),
      search: z.string().optional(),
      startDate: z.date().optional(),
      endDate: z.date().optional(),
    }))
    .query(async ({ ctx, input }) => {
      return getTransactions(ctx.user.id, input);
    }),
  get: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      return getTransactionById(input.id, ctx.user.id);
    }),
  create: protectedProcedure
    .input(z.object({
      type: z.enum(["income", "expense"]),
      amount: z.string(),
      description: z.string().min(1).max(255),
      notes: z.string().optional(),
      categoryId: z.number().optional(),
      date: z.date(),
      isRecurring: z.boolean().default(false),
      recurringInterval: z.enum(["daily", "weekly", "monthly", "yearly"]).optional(),
      tags: z.array(z.string()).default([]),
    }))
    .mutation(async ({ ctx, input }) => {
      await createTransaction({ ...input, userId: ctx.user.id });
      return { success: true };
    }),
  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      type: z.enum(["income", "expense"]).optional(),
      amount: z.string().optional(),
      description: z.string().min(1).max(255).optional(),
      notes: z.string().optional(),
      categoryId: z.number().optional(),
      date: z.date().optional(),
      isRecurring: z.boolean().optional(),
      recurringInterval: z.enum(["daily", "weekly", "monthly", "yearly"]).optional(),
      tags: z.array(z.string()).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      await updateTransaction(id, ctx.user.id, data);
      return { success: true };
    }),
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await deleteTransaction(input.id, ctx.user.id);
      return { success: true };
    }),
  uploadReceipt: protectedProcedure
    .input(z.object({ transactionId: z.number(), base64: z.string(), mimeType: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const buffer = Buffer.from(input.base64, "base64");
      const key = `receipts/${ctx.user.id}/${input.transactionId}-${Date.now()}`;
      const { url } = await storagePut(key, buffer, input.mimeType);
      await updateTransaction(input.transactionId, ctx.user.id, { receiptUrl: url, receiptKey: key });
      return { url };
    }),
  summary: protectedProcedure
    .input(z.object({ startDate: z.date(), endDate: z.date() }))
    .query(async ({ ctx, input }) => {
      return getFinancialSummary(ctx.user.id, input.startDate, input.endDate);
    }),
  spendingByCategory: protectedProcedure
    .input(z.object({ startDate: z.date(), endDate: z.date() }))
    .query(async ({ ctx, input }) => {
      return getSpendingByCategory(ctx.user.id, input.startDate, input.endDate);
    }),
  monthlyComparison: protectedProcedure
    .input(z.object({ months: z.number().min(1).max(12).default(6) }))
    .query(async ({ ctx, input }) => {
      return getMonthlyComparison(ctx.user.id, input.months);
    }),
});

// ── Budgets Router ─────────────────────────────────────────────────────────
const budgetsRouter = router({
  list: protectedProcedure
    .input(z.object({ month: z.number().min(1).max(12), year: z.number().min(2000) }))
    .query(async ({ ctx, input }) => {
      return getBudgets(ctx.user.id, input.month, input.year);
    }),
  create: protectedProcedure
    .input(z.object({
      name: z.string().min(1).max(100),
      limitAmount: z.string(),
      categoryId: z.number().optional(),
      period: z.enum(["monthly", "weekly", "yearly"]).default("monthly"),
      alertThreshold: z.number().min(0).max(100).default(80),
      alertEnabled: z.boolean().default(true),
      month: z.number().min(1).max(12),
      year: z.number().min(2000),
    }))
    .mutation(async ({ ctx, input }) => {
      await createBudget({ ...input, userId: ctx.user.id });
      return { success: true };
    }),
  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      name: z.string().min(1).max(100).optional(),
      limitAmount: z.string().optional(),
      alertThreshold: z.number().min(0).max(100).optional(),
      alertEnabled: z.boolean().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      await updateBudget(id, ctx.user.id, data);
      return { success: true };
    }),
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await deleteBudget(input.id, ctx.user.id);
      return { success: true };
    }),
});

// ── Goals Router ───────────────────────────────────────────────────────────
const goalsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return getGoals(ctx.user.id);
  }),
  create: protectedProcedure
    .input(z.object({
      name: z.string().min(1).max(100),
      description: z.string().optional(),
      targetAmount: z.string(),
      currentAmount: z.string().default("0"),
      icon: z.string().default("target"),
      color: z.string().default("#8B5CF6"),
      deadline: z.date().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      await createGoal({ ...input, userId: ctx.user.id });
      return { success: true };
    }),
  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      name: z.string().min(1).max(100).optional(),
      description: z.string().optional(),
      targetAmount: z.string().optional(),
      currentAmount: z.string().optional(),
      icon: z.string().optional(),
      color: z.string().optional(),
      deadline: z.date().optional(),
      isCompleted: z.boolean().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      await updateGoal(id, ctx.user.id, data);
      return { success: true };
    }),
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await deleteGoal(input.id, ctx.user.id);
      return { success: true };
    }),
});

// ── AI Router ──────────────────────────────────────────────────────────────
const aiRouter = router({
  insights: protectedProcedure
    .input(z.object({
      income: z.number(),
      expense: z.number(),
      balance: z.number(),
      topCategories: z.array(z.object({ name: z.string(), total: z.number() })),
      monthlyTrend: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const prompt = `Você é um assistente financeiro pessoal especializado. Analise os dados financeiros abaixo e forneça insights personalizados em português brasileiro.

Dados financeiros do mês atual:
- Receita total: R$ ${input.income.toFixed(2)}
- Despesa total: R$ ${input.expense.toFixed(2)}
- Saldo: R$ ${input.balance.toFixed(2)}
- Taxa de gastos: ${input.income > 0 ? ((input.expense / input.income) * 100).toFixed(1) : 0}%

Top categorias de gastos:
${input.topCategories.map((c) => `- ${c.name}: R$ ${c.total.toFixed(2)}`).join("\n")}

${input.monthlyTrend ? `Tendência: ${input.monthlyTrend}` : ""}

Forneça:
1. Uma análise concisa da situação financeira (2-3 frases)
2. 3 insights específicos e acionáveis
3. 2-3 recomendações de economia personalizadas
4. Um alerta se houver gastos excessivos

Responda em formato JSON com as chaves: "analysis", "insights" (array), "recommendations" (array), "alerts" (array).`;

      try {
        const response = await invokeLLM({
          messages: [{ role: "user", content: prompt }],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "financial_insights",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  analysis: { type: "string" },
                  insights: { type: "array", items: { type: "string" } },
                  recommendations: { type: "array", items: { type: "string" } },
                  alerts: { type: "array", items: { type: "string" } },
                },
                required: ["analysis", "insights", "recommendations", "alerts"],
                additionalProperties: false,
              },
            },
          },
        });

        const rawContent = response.choices[0]?.message?.content;
        const content = typeof rawContent === 'string' ? rawContent : null;
        if (!content) throw new Error("No response from AI");
        return JSON.parse(content);
      } catch (error) {
        return {
          analysis: "Análise indisponível no momento. Tente novamente em instantes.",
          insights: ["Continue registrando suas transações para obter insights personalizados."],
          recommendations: ["Mantenha um registro detalhado de seus gastos mensais."],
          alerts: [],
        };
      }
    }),
  chat: protectedProcedure
    .input(z.object({
      message: z.string().min(1).max(1000),
      context: z.object({
        income: z.number(),
        expense: z.number(),
        balance: z.number(),
      }).optional(),
    }))
    .mutation(async ({ input }) => {
      const systemPrompt = `Você é o FinanceFlow AI, um assistente financeiro pessoal inteligente e amigável. 
Responda sempre em português brasileiro de forma clara e objetiva.
${input.context ? `Contexto financeiro atual: Receita R$ ${input.context.income.toFixed(2)}, Despesa R$ ${input.context.expense.toFixed(2)}, Saldo R$ ${input.context.balance.toFixed(2)}` : ""}
Forneça conselhos práticos, personalizados e motivadores sobre finanças pessoais.`;

      try {
        const response = await invokeLLM({
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: input.message },
          ],
        });
        const content = response.choices[0]?.message?.content;
        const reply = typeof content === 'string' ? content : "Desculpe, não consegui processar sua mensagem.";
        return { reply };
      } catch {
        return { reply: "Serviço de IA temporariamente indisponível. Tente novamente em instantes." };
      }
    }),
});

// ── App Router ─────────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,
  auth: authRouter,
  categories: categoriesRouter,
  transactions: transactionsRouter,
  budgets: budgetsRouter,
  goals: goalsRouter,
  ai: aiRouter,
});

export type AppRouter = typeof appRouter;
