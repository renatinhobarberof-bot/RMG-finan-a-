import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { COOKIE_NAME } from "../shared/const";

// ── Mock DB helpers ────────────────────────────────────────────────────────
vi.mock("./db", () => ({
  upsertUser: vi.fn(),
  getUserByOpenId: vi.fn(),
  updateUserProfile: vi.fn(),
  getCategoriesByUser: vi.fn().mockResolvedValue([
    { id: 1, name: "Alimentação", icon: "utensils", color: "#8B5CF6", type: "expense", isDefault: true, userId: 1 },
    { id: 2, name: "Salário", icon: "briefcase", color: "#10B981", type: "income", isDefault: true, userId: 1 },
  ]),
  createCategory: vi.fn(),
  updateCategory: vi.fn(),
  deleteCategory: vi.fn(),
  seedDefaultCategories: vi.fn(),
  getTransactions: vi.fn().mockResolvedValue({ items: [], total: 0 }),
  getTransactionById: vi.fn(),
  createTransaction: vi.fn(),
  updateTransaction: vi.fn(),
  deleteTransaction: vi.fn(),
  getFinancialSummary: vi.fn().mockResolvedValue({ income: 5000, expense: 3000, balance: 2000, transactionCount: 10 }),
  getSpendingByCategory: vi.fn().mockResolvedValue([]),
  getMonthlyComparison: vi.fn().mockResolvedValue([]),
  getBudgets: vi.fn().mockResolvedValue([]),
  createBudget: vi.fn(),
  updateBudget: vi.fn(),
  deleteBudget: vi.fn(),
  getGoals: vi.fn().mockResolvedValue([]),
  createGoal: vi.fn(),
  updateGoal: vi.fn(),
  deleteGoal: vi.fn(),
}));

vi.mock("./storage", () => ({
  storagePut: vi.fn().mockResolvedValue({ key: "test-key", url: "/manus-storage/test-key" }),
}));

vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [{ message: { content: JSON.stringify({ analysis: "OK", insights: [], recommendations: [], alerts: [] }) } }],
  }),
}));

// ── Auth context factory ───────────────────────────────────────────────────
type AuthUser = NonNullable<TrpcContext["user"]>;

function makeCtx(overrides?: Partial<AuthUser>): TrpcContext {
  const clearedCookies: string[] = [];
  const user: AuthUser = {
    id: 1,
    openId: "test-open-id",
    email: "test@financeflow.app",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    ...overrides,
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: (name: string) => clearedCookies.push(name),
    } as TrpcContext["res"],
  };
}

// ── Tests ──────────────────────────────────────────────────────────────────
describe("auth", () => {
  it("me returns current user", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result?.id).toBe(1);
    expect(result?.email).toBe("test@financeflow.app");
  });

  it("logout clears session cookie", async () => {
    const cleared: Array<{ name: string; options: Record<string, unknown> }> = [];
    const ctx: TrpcContext = {
      user: makeCtx().user,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {
        clearCookie: (name: string, options: Record<string, unknown>) => {
          cleared.push({ name, options });
        },
      } as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
    expect(cleared[0]?.name).toBe(COOKIE_NAME);
    expect(cleared[0]?.options).toMatchObject({ maxAge: -1 });
  });
});

describe("categories", () => {
  it("list returns seeded categories", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.categories.list();
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
    expect(result[0]).toHaveProperty("name");
    expect(result[0]).toHaveProperty("icon");
  });
});

describe("transactions", () => {
  it("list returns paginated result", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.transactions.list({ limit: 10, offset: 0 });
    expect(result).toHaveProperty("items");
    expect(result).toHaveProperty("total");
    expect(Array.isArray(result.items)).toBe(true);
  });

  it("summary returns income/expense/balance", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1);
    const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    const result = await caller.transactions.summary({ startDate: start, endDate: end });
    expect(result).toHaveProperty("income");
    expect(result).toHaveProperty("expense");
    expect(result).toHaveProperty("balance");
    expect(result.income).toBe(5000);
    expect(result.expense).toBe(3000);
    expect(result.balance).toBe(2000);
  });

  it("create validates required fields", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.transactions.create({
        type: "expense",
        amount: "150.00",
        description: "Supermercado",
        date: new Date(),
        isRecurring: false,
        tags: [],
      })
    ).resolves.toEqual({ success: true });
  });
});

describe("budgets", () => {
  it("list returns budgets for month/year", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.budgets.list({ month: 6, year: 2026 });
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("goals", () => {
  it("list returns goals", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.goals.list();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("ai", () => {
  it("chat returns a reply", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.ai.chat({
      message: "Como posso economizar mais?",
      context: { income: 5000, expense: 3000, balance: 2000 },
    });
    expect(result).toHaveProperty("reply");
    expect(typeof result.reply).toBe("string");
  });

  it("insights returns analysis structure", async () => {
    const ctx = makeCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.ai.insights({
      income: 5000,
      expense: 3000,
      balance: 2000,
      topCategories: [{ name: "Alimentação", total: 1500 }],
    });
    expect(result).toHaveProperty("analysis");
    expect(result).toHaveProperty("insights");
    expect(result).toHaveProperty("recommendations");
    expect(result).toHaveProperty("alerts");
  });
});
