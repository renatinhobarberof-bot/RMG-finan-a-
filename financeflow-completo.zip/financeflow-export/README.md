# FinanceFlow — Controle Financeiro Inteligente

> App de finanças pessoais premium com IA, visual fintech moderno e PWA instalável no iPhone.

---

## Visão Geral

O **FinanceFlow** é uma Progressive Web App (PWA) completa de controle financeiro pessoal, com visual inspirado em Nubank, Revolut e Notion. Construído com React 19 + TypeScript + tRPC + Drizzle ORM + MySQL, com suporte a instalação nativa no iOS via Safari.

---

## Funcionalidades

| Módulo | Funcionalidades |
|---|---|
| **Autenticação** | Login via OAuth, sessão persistente, perfil editável |
| **Dashboard** | Saldo diário/semanal/mensal, gráfico de evolução, últimas transações |
| **Transações** | CRUD completo, categorias, upload de comprovantes, busca e filtros |
| **Orçamento** | Limites mensais por categoria, alertas, barra de progresso |
| **Metas** | Metas financeiras com prazo e progresso |
| **Relatórios** | Gráficos animados, exportação PDF real e Excel (.xlsx) |
| **IA Financeira** | Insights personalizados, chat financeiro, detecção de gastos excessivos |
| **Configurações** | Tema claro/escuro, notificações push, backup, segurança |
| **PWA iOS** | Instalável via Safari, suporte offline, ícones nativos |

---

## Instalação no iPhone (iOS)

### Passo a passo para instalar o FinanceFlow como app nativo:

1. Abra o **Safari** no iPhone (obrigatório — Chrome e outros não suportam instalação de PWA no iOS)
2. Acesse a URL do app: `https://seu-dominio.manus.space`
3. Toque no ícone de **Compartilhar** (quadrado com seta para cima) na barra inferior do Safari
4. Role para baixo e toque em **"Adicionar à Tela de Início"**
5. Confirme o nome **"FinanceFlow"** e toque em **"Adicionar"**
6. O app aparecerá na sua tela inicial como um ícone nativo
7. Abra pelo ícone — ele iniciará em modo tela cheia, sem barra do Safari

> **Dica:** O app funciona offline após a primeira abertura, graças ao Service Worker.

---

## Estrutura do Projeto

```
financeflow/
├── client/
│   ├── public/
│   │   ├── manifest.json          # Configuração PWA
│   │   ├── sw.js                  # Service Worker (offline)
│   │   └── icons/                 # Ícones PWA (16px a 512px)
│   └── src/
│       ├── pages/
│       │   ├── SplashScreen.tsx   # Tela de carregamento
│       │   ├── Onboarding.tsx     # Slides de boas-vindas
│       │   ├── Login.tsx          # Autenticação
│       │   ├── Home.tsx           # Dashboard principal
│       │   ├── Wallet.tsx         # Carteira e metas
│       │   ├── Transactions.tsx   # Lista de transações
│       │   ├── TransactionForm.tsx # Criar/editar transação
│       │   ├── Statistics.tsx     # Relatórios e gráficos
│       │   ├── Budget.tsx         # Orçamentos e metas
│       │   ├── AIAssistant.tsx    # IA Financeira
│       │   ├── Profile.tsx        # Perfil do usuário
│       │   └── Settings.tsx       # Configurações
│       ├── components/
│       │   ├── AppLayout.tsx      # Layout base com animações
│       │   └── BottomNav.tsx      # Navegação inferior
│       ├── hooks/
│       │   └── useFinance.ts      # Hooks de dados financeiros
│       └── index.css              # Design system fintech
├── server/
│   ├── routers.ts                 # tRPC procedures
│   ├── db.ts                      # Helpers do banco de dados
│   └── financeflow.test.ts        # Testes vitest (11 testes)
└── drizzle/
    └── schema.ts                  # Schema do banco de dados
```

---

## Banco de Dados

### Tabelas

| Tabela | Descrição |
|---|---|
| `users` | Usuários com perfil, configurações e preferências |
| `categories` | Categorias de transações (padrão + personalizadas) |
| `transactions` | Receitas e despesas com metadados completos |
| `budgets` | Orçamentos mensais por categoria com alertas |
| `goals` | Metas financeiras com progresso e prazo |

### Categorias Padrão (criadas automaticamente no primeiro acesso)

**Despesas:** Alimentação, Transporte, Moradia, Saúde, Lazer, Educação, Compras, Outros

**Receitas:** Salário, Freelance, Investimentos, Outros

---

## Tecnologias

| Camada | Tecnologia |
|---|---|
| Frontend | React 19, TypeScript, Tailwind CSS 4, Framer Motion |
| Backend | Express 4, tRPC 11, Node.js |
| Banco de dados | MySQL/TiDB via Drizzle ORM |
| Gráficos | Recharts |
| Exportação | jsPDF + jspdf-autotable (PDF), SheetJS/XLSX (Excel) |
| IA | LLM via Manus Forge API |
| Armazenamento | S3 (comprovantes e avatares) |
| Autenticação | Manus OAuth 2.0 |
| PWA | Service Worker, Web App Manifest |

---

## Rodar Localmente

```bash
# Instalar dependências
pnpm install

# Iniciar servidor de desenvolvimento
pnpm dev

# Executar testes
pnpm test

# Build de produção
pnpm build
```

---

## Publicar na App Store (via PWA)

O FinanceFlow é uma PWA, portanto **não requer publicação na App Store** para funcionar no iPhone. A instalação é feita diretamente pelo Safari.

Para distribuição via App Store, é possível empacotar a PWA usando:

1. **PWABuilder** (gratuito): Acesse [pwabuilder.com](https://pwabuilder.com), insira a URL do app e gere o pacote iOS (.ipa)
2. **Capacitor** (Ionic): Converta a PWA em app nativo com `npx cap add ios`
3. **Expo** (React Native Web): Para uma versão nativa completa

> Para publicação na App Store, é necessário uma conta Apple Developer ($99/ano) e um Mac com Xcode.

---

## Variáveis de Ambiente

Todas as variáveis são injetadas automaticamente pela plataforma Manus:

| Variável | Descrição |
|---|---|
| `DATABASE_URL` | Conexão MySQL/TiDB |
| `JWT_SECRET` | Segredo para cookies de sessão |
| `BUILT_IN_FORGE_API_KEY` | Chave da API de IA |
| `BUILT_IN_FORGE_API_URL` | URL da API de IA |

---

## Design System

O app utiliza um design system fintech premium com:

- **Paleta escura:** Fundo `oklch(0.08 0.012 270)`, cards `oklch(0.12 0.015 270)`
- **Roxo primário:** `oklch(0.65 0.22 295)` — identidade visual
- **Verde financeiro:** `oklch(0.72 0.18 160)` — receitas
- **Vermelho:** `oklch(0.62 0.22 25)` — despesas
- **Tipografia:** Plus Jakarta Sans (Google Fonts)
- **Animações:** Framer Motion com easing `cubic-bezier(0.23, 1, 0.32, 1)`
- **Microinterações:** `btn-press` (scale 0.96 no :active), `card-hover`

---

## Testes

```bash
pnpm test
# 11 testes passando:
# ✓ auth.me, auth.logout
# ✓ categories.list
# ✓ transactions.list, transactions.summary, transactions.create
# ✓ budgets.list
# ✓ goals.list
# ✓ ai.chat, ai.insights
```

---

Desenvolvido com ❤️ usando Manus AI
