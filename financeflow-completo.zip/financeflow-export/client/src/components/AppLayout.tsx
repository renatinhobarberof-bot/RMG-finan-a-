import { ReactNode } from "react";
import { motion } from "framer-motion";
import BottomNav from "./BottomNav";

interface AppLayoutProps {
  children: ReactNode;
  hideNav?: boolean;
  className?: string;
}

const pageVariants = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -10 },
};

export default function AppLayout({ children, hideNav = false, className = "" }: AppLayoutProps) {
  return (
    <div className="min-h-dvh bg-background flex flex-col max-w-[480px] mx-auto relative">
      <motion.main
        variants={pageVariants}
        initial="initial"
        animate="animate"
        exit="exit"
        transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }}
        className={`flex-1 overflow-y-auto scroll-smooth-ios no-scrollbar ${hideNav ? "" : "pb-bottom-nav"} ${className}`}
      >
        {children}
      </motion.main>
      {!hideNav && <BottomNav />}
    </div>
  );
}
