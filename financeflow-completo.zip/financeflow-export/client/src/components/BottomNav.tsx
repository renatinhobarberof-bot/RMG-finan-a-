import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Home, Wallet, ArrowLeftRight, BarChart3, Sparkles } from "lucide-react";

const navItems = [
  { path: "/home", icon: Home, label: "Home" },
  { path: "/wallet", icon: Wallet, label: "Carteira" },
  { path: "/transactions", icon: ArrowLeftRight, label: "Transações" },
  { path: "/statistics", icon: BarChart3, label: "Relatórios" },
  { path: "/ai", icon: Sparkles, label: "IA" },
];

export default function BottomNav() {
  const [location, navigate] = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 glass-strong border-t border-border/50"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
      <div className="flex items-center justify-around px-2 py-2 max-w-[480px] mx-auto">
        {navItems.map((item) => {
          const isActive = location === item.path || (item.path === "/home" && location === "/home");
          const Icon = item.icon;

          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all duration-200 btn-press relative min-w-[56px]"
            >
              {isActive && (
                <motion.div
                  layoutId="nav-indicator"
                  className="absolute inset-0 bg-primary/15 rounded-xl"
                  transition={{ type: "spring", stiffness: 400, damping: 30 }}
                />
              )}
              <motion.div
                animate={{ scale: isActive ? 1.1 : 1 }}
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
              >
                <Icon
                  size={22}
                  className={isActive ? "text-primary" : "text-muted-foreground"}
                  strokeWidth={isActive ? 2.5 : 1.8}
                />
              </motion.div>
              <span className={`text-[10px] font-semibold tracking-wide transition-colors ${
                isActive ? "text-primary" : "text-muted-foreground"
              }`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
