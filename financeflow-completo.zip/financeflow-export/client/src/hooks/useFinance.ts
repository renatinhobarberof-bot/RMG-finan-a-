import { useMemo } from "react";
import { trpc } from "@/lib/trpc";

export function useMonthSummary() {
  const now = new Date();
  const startDate = useMemo(() => new Date(now.getFullYear(), now.getMonth(), 1), []);
  const endDate = useMemo(() => new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59), []);

  return trpc.transactions.summary.useQuery({ startDate, endDate });
}

export function useWeekSummary() {
  const now = new Date();
  const day = now.getDay();
  const startDate = useMemo(() => {
    const d = new Date(now);
    d.setDate(d.getDate() - day);
    d.setHours(0, 0, 0, 0);
    return d;
  }, []);
  const endDate = useMemo(() => new Date(), []);

  return trpc.transactions.summary.useQuery({ startDate, endDate });
}

export function useDaySummary() {
  const startDate = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  }, []);
  const endDate = useMemo(() => new Date(), []);

  return trpc.transactions.summary.useQuery({ startDate, endDate });
}

export function useRecentTransactions(limit = 10) {
  return trpc.transactions.list.useQuery({ limit, offset: 0 });
}

export function useCategorySpending() {
  const now = new Date();
  const startDate = useMemo(() => new Date(now.getFullYear(), now.getMonth(), 1), []);
  const endDate = useMemo(() => new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59), []);

  return trpc.transactions.spendingByCategory.useQuery({ startDate, endDate });
}

export function useMonthlyComparison(months = 6) {
  return trpc.transactions.monthlyComparison.useQuery({ months });
}

export function formatCurrency(value: number, currency = "BRL"): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
  }).format(value);
}

export function formatDate(date: Date | string): string {
  const d = new Date(date);
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(d);
}

export function formatDateShort(date: Date | string): string {
  const d = new Date(date);
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "short",
  }).format(d);
}

export function getMonthName(month: number): string {
  return new Intl.DateTimeFormat("pt-BR", { month: "long" }).format(new Date(2024, month - 1, 1));
}

export const CATEGORY_ICONS: Record<string, string> = {
  "utensils": "🍽️",
  "car": "🚗",
  "home": "🏠",
  "heart": "❤️",
  "gamepad-2": "🎮",
  "book-open": "📚",
  "shopping-bag": "🛍️",
  "briefcase": "💼",
  "laptop": "💻",
  "trending-up": "📈",
  "more-horizontal": "⋯",
  "circle": "⭕",
  "target": "🎯",
  "star": "⭐",
  "zap": "⚡",
  "coffee": "☕",
  "music": "🎵",
  "plane": "✈️",
  "gift": "🎁",
  "phone": "📱",
};
