import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import SplashScreen from "./pages/SplashScreen";
import Onboarding from "./pages/Onboarding";
import Login from "./pages/Login";
import Home from "./pages/Home";
import Wallet from "./pages/Wallet";
import Transactions from "./pages/Transactions";
import TransactionForm from "./pages/TransactionForm";
import Statistics from "./pages/Statistics";
import Budget from "./pages/Budget";
import AIAssistant from "./pages/AIAssistant";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";

function Router() {
  return (
    <Switch>
      <Route path="/" component={SplashScreen} />
      <Route path="/onboarding" component={Onboarding} />
      <Route path="/login" component={Login} />
      <Route path="/home" component={Home} />
      <Route path="/wallet" component={Wallet} />
      <Route path="/transactions" component={Transactions} />
      <Route path="/transactions/new" component={TransactionForm} />
      <Route path="/transactions/:id/edit" component={TransactionForm} />
      <Route path="/statistics" component={Statistics} />
      <Route path="/budget" component={Budget} />
      <Route path="/ai" component={AIAssistant} />
      <Route path="/profile" component={Profile} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" switchable>
        <TooltipProvider>
          <Toaster
            position="top-center"
            toastOptions={{
              style: {
                background: "oklch(0.13 0.015 270)",
                border: "1px solid oklch(0.22 0.02 270)",
                color: "oklch(0.97 0.005 270)",
                borderRadius: "0.75rem",
                fontFamily: "'Plus Jakarta Sans', sans-serif",
              },
            }}
          />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
