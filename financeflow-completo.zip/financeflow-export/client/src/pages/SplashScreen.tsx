import { useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

export default function SplashScreen() {
  const [, navigate] = useLocation();
  const { user, loading } = useAuth();
  const { data: userProfile } = trpc.auth.me.useQuery(undefined, { enabled: !!user });

  useEffect(() => {
    if (loading) return;

    const timer = setTimeout(() => {
      if (!user) {
        navigate("/onboarding");
      } else {
        navigate("/home");
      }
    }, 2200);

    return () => clearTimeout(timer);
  }, [user, loading, navigate]);

  return (
    <div className="min-h-dvh bg-background flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 0.15, scale: 1 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] rounded-full"
          style={{ background: "radial-gradient(circle, oklch(0.65 0.22 295) 0%, transparent 70%)" }}
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 0.08, scale: 1 }}
          transition={{ duration: 2, ease: "easeOut", delay: 0.3 }}
          className="absolute top-1/4 right-1/4 w-[200px] h-[200px] rounded-full"
          style={{ background: "radial-gradient(circle, oklch(0.72 0.18 160) 0%, transparent 70%)" }}
        />
      </div>

      {/* Logo */}
      <motion.div
        initial={{ opacity: 0, scale: 0.7, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1], delay: 0.2 }}
        className="relative z-10 flex flex-col items-center gap-6"
      >
        {/* Icon */}
        <motion.div
          animate={{ boxShadow: ["0 0 20px oklch(0.52 0.22 170 / 0.3)", "0 0 50px oklch(0.52 0.22 170 / 0.5)", "0 0 20px oklch(0.52 0.22 170 / 0.3)"] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="w-24 h-24 rounded-3xl flex items-center justify-center border-2 border-emerald-400/30"
          style={{ background: "linear-gradient(135deg, oklch(0.2 0.08 170), oklch(0.15 0.08 170))" }}
        >
          <span className="text-3xl font-black text-emerald-400 tracking-tight">R</span>
          <motion.div
            animate={{ scale: [1, 1.3, 1] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
            className="absolute top-4 right-4 w-3 h-3 rounded-full bg-emerald-400"
          />
        </motion.div>

        {/* App name */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="text-center"
        >
          <h1 className="text-3xl font-black tracking-tight text-emerald-400">RMG Finança</h1>
          <p className="text-muted-foreground text-sm mt-1 font-medium">Gestão Financeira Inteligente</p>
        </motion.div>
      </motion.div>

      {/* Loading indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="absolute bottom-16 flex flex-col items-center gap-3"
      >
        <div className="flex gap-1.5">
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              animate={{ scale: [1, 1.4, 1], opacity: [0.4, 1, 0.4] }}
              transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.15, ease: "easeInOut" }}
              className="w-2 h-2 rounded-full bg-primary"
            />
          ))}
        </div>
        <p className="text-muted-foreground text-xs">Carregando...</p>
      </motion.div>
    </div>
  );
}
