import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { useTheme } from "@/contexts/ThemeContext";
import AppLayout from "@/components/AppLayout";
import { Moon, Sun, Bell, Shield, Download, Info, ChevronRight, ArrowLeft, Palette, Database } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

export default function Settings() {
  const [, navigate] = useLocation();
  const { user, loading: authLoading } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [notifications, setNotifications] = useState(true);
  const [budgetAlerts, setBudgetAlerts] = useState(true);
  const [weeklyReport, setWeeklyReport] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  const handleExportData = () => {
    toast.info("Preparando exportação...");
    setTimeout(() => toast.success("Dados exportados com sucesso!"), 1500);
  };

  const handleRequestNotifications = async () => {
    if ("Notification" in window) {
      const permission = await Notification.requestPermission();
      if (permission === "granted") {
        toast.success("Notificações ativadas!");
        setNotifications(true);
      } else {
        toast.error("Permissão negada. Ative nas configurações do iPhone.");
      }
    } else {
      toast.info("Notificações não suportadas neste dispositivo");
    }
  };

  const sections = [
    {
      title: "Aparência",
      items: [
        {
          icon: theme === "dark" ? Moon : Sun,
          label: "Tema Escuro",
          color: "oklch(0.65 0.22 295)",
          right: (
            <Switch
              checked={theme === "dark"}
              onCheckedChange={() => toggleTheme?.()}
            />
          ),
        },
      ],
    },
    {
      title: "Notificações",
      items: [
        {
          icon: Bell,
          label: "Notificações Push",
          color: "oklch(0.72 0.18 220)",
          right: (
            <Switch
              checked={notifications}
              onCheckedChange={(v) => {
                if (v) handleRequestNotifications();
                else setNotifications(false);
              }}
            />
          ),
        },
        {
          icon: Bell,
          label: "Alertas de Orçamento",
          color: "oklch(0.72 0.18 50)",
          right: (
            <Switch checked={budgetAlerts} onCheckedChange={setBudgetAlerts} />
          ),
        },
        {
          icon: Bell,
          label: "Relatório Semanal",
          color: "oklch(0.72 0.18 160)",
          right: (
            <Switch checked={weeklyReport} onCheckedChange={setWeeklyReport} />
          ),
        },
      ],
    },
    {
      title: "Dados",
      items: [
        {
          icon: Download,
          label: "Exportar Dados",
          color: "oklch(0.72 0.18 160)",
          right: <ChevronRight size={16} className="text-muted-foreground" />,
          onPress: handleExportData,
        },
        {
          icon: Database,
          label: "Backup na Nuvem",
          color: "oklch(0.65 0.22 295)",
          right: <ChevronRight size={16} className="text-muted-foreground" />,
          onPress: () => toast.info("Backup automático ativado"),
        },
      ],
    },
    {
      title: "Segurança",
      items: [
        {
          icon: Shield,
          label: "Autenticação Biométrica",
          color: "oklch(0.62 0.22 25)",
          right: <Switch checked={false} onCheckedChange={() => toast.info("Em breve disponível")} />,
        },
      ],
    },
    {
      title: "Sobre",
      items: [
        {
          icon: Info,
          label: "Versão do App",
          color: "oklch(0.55 0.01 270)",
          right: <span className="text-xs text-muted-foreground">1.0.0</span>,
        },
        {
          icon: Info,
          label: "Termos de Uso",
          color: "oklch(0.55 0.01 270)",
          right: <ChevronRight size={16} className="text-muted-foreground" />,
          onPress: () => toast.info("Termos de Uso"),
        },
        {
          icon: Info,
          label: "Política de Privacidade",
          color: "oklch(0.55 0.01 270)",
          right: <ChevronRight size={16} className="text-muted-foreground" />,
          onPress: () => toast.info("Política de Privacidade"),
        },
      ],
    },
  ];

  return (
    <AppLayout>
      <div className="px-5 pt-safe">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3 py-5">
          <button onClick={() => navigate("/profile")} className="w-10 h-10 rounded-xl bg-card border border-border/50 flex items-center justify-center btn-press">
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl font-black text-foreground">Configurações</h1>
        </motion.div>

        {/* PWA Install Hint */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="mb-5 p-4 rounded-2xl border border-primary/30 bg-primary/10">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
              <Palette size={16} className="text-primary" />
            </div>
            <div>
              <p className="text-sm font-bold text-foreground">Instalar no iPhone</p>
              <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                Toque em <strong>Compartilhar</strong> no Safari → <strong>Adicionar à Tela de Início</strong> para instalar o app.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Settings Sections */}
        <div className="space-y-6 pb-safe pb-8">
          {sections.map((section, si) => (
            <motion.div
              key={section.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + si * 0.08 }}
            >
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2 px-1">
                {section.title}
              </p>
              <div className="bg-card border border-border/50 rounded-2xl overflow-hidden">
                {section.items.map((item, ii) => (
                  <button
                    key={item.label}
                    onClick={item.onPress}
                    className={`w-full flex items-center gap-3 p-4 text-left transition-colors hover:bg-secondary/50 ${
                      ii < section.items.length - 1 ? "border-b border-border/30" : ""
                    }`}
                  >
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${item.color}20` }}>
                      <item.icon size={16} style={{ color: item.color }} />
                    </div>
                    <span className="flex-1 text-sm font-medium text-foreground">{item.label}</span>
                    {item.right}
                  </button>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
