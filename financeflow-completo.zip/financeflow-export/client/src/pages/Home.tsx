import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { formatCurrency, formatDateShort, useMonthSummary, useWeekSummary, useDaySummary, useRecentTransactions } from "@/hooks/useFinance";
import AppLayout from "@/components/AppLayout";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Bell, Plus, TrendingUp, TrendingDown, Wallet, ChevronRight, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { getLoginUrl } from "@/const";

const PERIOD_TABS = [
  { key: "day", label: "Hoje" },
  { key: "week", label: "Semana" },
  { key: "month", label: "Mês" },
] as const;

type Period = "day" | "week" | "month";

function AnimatedNumber({ value, prefix = "R$ " }: { value: number; prefix?: string }) {
  return (
    <motion.span
      key={value}
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
      className="tabular-nums"
    >
      {prefix}{Math.abs(value).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
    </motion.span>
  );
}

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="glass rounded-xl p-3 text-xs">
      <p className="text-muted-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <p key={p.name} style={{ color: p.color }} className="font-semibold">
          {p.name}: {formatCurrency(p.value)}
        </p>
      ))}
    </div>
  );
}

export default function Home() {
  const [, navigate] = useLocation();
  const { user, loading: authLoading } = useAuth();
  const [period, setPeriod] = useState<Period>("month");
  const [hideBalance, setHideBalance] = useState(false);

  const monthSummary = useMonthSummary();
  const weekSummary = useWeekSummary();
  const daySummary = useDaySummary();
  const recentTx = useRecentTransactions(8);
  const monthlyComparison = trpc.transactions.monthlyComparison.useQuery({ months: 6 });

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  const summaryData = period === "day" ? daySummary.data : period === "week" ? weekSummary.data : monthSummary.data;
  const summaryLoading = period === "day" ? daySummary.isLoading : period === "week" ? weekSummary.isLoading : monthSummary.isLoading;

  // Build chart data from monthly comparison
  const chartData = (() => {
    if (!monthlyComparison.data) return [];
    const map: Record<string, { month: string; income: number; expense: number }> = {};
    for (const row of monthlyComparison.data) {
      const key = row.month as string;
      if (!map[key]) {
        const [year, month] = key.split("-");
        const date = new Date(Number(year), Number(month) - 1, 1);
        map[key] = {
          month: date.toLocaleDateString("pt-BR", { month: "short" }),
          income: 0,
          expense: 0,
        };
      }
      if (row.type === "income") map[key].income = Number(row.total ?? 0);
      if (row.type === "expense") map[key].expense = Number(row.total ?? 0);
    }
    return Object.values(map);
  })();

  if (authLoading) {
    return (
      <AppLayout>
        <div className="p-6 space-y-4">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-40 w-full rounded-2xl" />
          <Skeleton className="h-48 w-full rounded-2xl" />
        </div>
      </AppLayout>
    );
  }

  const balance = summaryData?.balance ?? 0;
  const income = summaryData?.income ?? 0;
  const expense = summaryData?.expense ?? 0;

  return (
    <AppLayout>
      <div className="px-5 pt-safe">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between py-5"
        >
          <div>
            <p className="text-muted-foreground text-sm font-medium">Olá,</p>
            <h1 className="text-xl font-black text-foreground">
              {user?.name?.split(" ")[0] ?? "Usuário"} 👋
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate("/profile")}
              className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center border border-primary/30 btn-press"
            >
              <span className="text-sm font-bold text-primary">
                {user?.name?.charAt(0).toUpperCase() ?? "U"}
              </span>
            </button>
          </div>
        </motion.div>

        {/* Balance Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="rounded-3xl p-6 mb-5 relative overflow-hidden"
          style={{
            background: "linear-gradient(135deg, oklch(0.65 0.22 295 / 0.9), oklch(0.45 0.22 250 / 0.9))",
            boxShadow: "0 20px 60px oklch(0.65 0.22 295 / 0.3)",
          }}
        >
          {/* Background pattern */}
          <div className="absolute inset-0 opacity-10"
            style={{
              backgroundImage: "radial-gradient(circle at 80% 20%, white 1px, transparent 1px)",
              backgroundSize: "30px 30px",
            }} />

          <div className="relative z-10">
            {/* Period tabs */}
            <div className="flex gap-1 mb-5 bg-white/10 rounded-xl p-1 w-fit">
              {PERIOD_TABS.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setPeriod(tab.key)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all duration-200 ${
                    period === tab.key ? "bg-white text-purple-700" : "text-white/70"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Balance */}
            <div className="mb-5">
              <div className="flex items-center gap-2 mb-1">
                <p className="text-white/70 text-sm font-medium">Saldo</p>
                <button onClick={() => setHideBalance(!hideBalance)} className="text-white/50">
                  {hideBalance ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
              <div className="text-4xl font-black text-white">
                {summaryLoading ? (
                  <Skeleton className="h-10 w-48 bg-white/20" />
                ) : hideBalance ? (
                  <span>R$ ••••••</span>
                ) : (
                  <AnimatedNumber value={balance} />
                )}
              </div>
            </div>

            {/* Income / Expense */}
            <div className="flex gap-4">
              <div className="flex-1 bg-white/10 rounded-2xl p-3">
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-6 h-6 rounded-full bg-green-400/20 flex items-center justify-center">
                    <TrendingUp size={12} className="text-green-300" />
                  </div>
                  <span className="text-white/70 text-xs">Receitas</span>
                </div>
                {summaryLoading ? (
                  <Skeleton className="h-5 w-24 bg-white/20" />
                ) : (
                  <p className="text-white font-bold text-sm tabular-nums">
                    {hideBalance ? "••••" : formatCurrency(income)}
                  </p>
                )}
              </div>
              <div className="flex-1 bg-white/10 rounded-2xl p-3">
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-6 h-6 rounded-full bg-red-400/20 flex items-center justify-center">
                    <TrendingDown size={12} className="text-red-300" />
                  </div>
                  <span className="text-white/70 text-xs">Despesas</span>
                </div>
                {summaryLoading ? (
                  <Skeleton className="h-5 w-24 bg-white/20" />
                ) : (
                  <p className="text-white font-bold text-sm tabular-nums">
                    {hideBalance ? "••••" : formatCurrency(expense)}
                  </p>
                )}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card border border-border/50 rounded-3xl p-5 mb-5"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-foreground">Evolução Financeira</h2>
            <span className="text-xs text-muted-foreground">6 meses</span>
          </div>
          {monthlyComparison.isLoading ? (
            <Skeleton className="h-36 w-full rounded-xl" />
          ) : chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={140}>
              <AreaChart data={chartData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                <defs>
                  <linearGradient id="incomeGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.72 0.18 160)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.72 0.18 160)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="expenseGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.65 0.22 295)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.65 0.22 295)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" tick={{ fontSize: 10, fill: "oklch(0.55 0.01 270)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 9, fill: "oklch(0.55 0.01 270)" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="income" name="Receita" stroke="oklch(0.72 0.18 160)" strokeWidth={2} fill="url(#incomeGrad)" dot={false} />
                <Area type="monotone" dataKey="expense" name="Despesa" stroke="oklch(0.65 0.22 295)" strokeWidth={2} fill="url(#expenseGrad)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-36 flex items-center justify-center text-muted-foreground text-sm">
              Sem dados suficientes
            </div>
          )}
          <div className="flex gap-4 mt-3">
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              <span className="text-xs text-muted-foreground">Receita</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-primary" />
              <span className="text-xs text-muted-foreground">Despesa</span>
            </div>
          </div>
        </motion.div>

        {/* Recent Transactions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-foreground">Últimas Transações</h2>
            <button
              onClick={() => navigate("/transactions")}
              className="flex items-center gap-1 text-xs text-primary font-semibold"
            >
              Ver todas <ChevronRight size={14} />
            </button>
          </div>

          {recentTx.isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-16 w-full rounded-2xl" />
              ))}
            </div>
          ) : recentTx.data?.items.length === 0 ? (
            <div className="bg-card border border-border/50 rounded-2xl p-8 text-center">
              <Wallet size={32} className="mx-auto mb-3 text-muted-foreground" />
              <p className="text-muted-foreground text-sm">Nenhuma transação ainda</p>
              <Button
                size="sm"
                className="mt-3"
                onClick={() => navigate("/transactions/new")}
              >
                Adicionar primeira transação
              </Button>
            </div>
          ) : (
            <div className="space-y-2 stagger-children">
              {recentTx.data?.items.map((tx, i) => (
                <motion.div
                  key={tx.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => navigate(`/transactions/${tx.id}/edit`)}
                  className="flex items-center gap-3 p-3.5 bg-card border border-border/50 rounded-2xl card-hover cursor-pointer"
                >
                  {/* Category icon */}
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center text-lg flex-shrink-0"
                    style={{ backgroundColor: `${tx.categoryColor ?? "#8B5CF6"}20` }}
                  >
                    {tx.categoryIcon ? (
                      <span className="text-base">{getCategoryEmoji(tx.categoryIcon)}</span>
                    ) : (
                      <span className="text-base">{tx.type === "income" ? "💰" : "💸"}</span>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground truncate">{tx.description}</p>
                    <p className="text-xs text-muted-foreground">
                      {tx.categoryName ?? (tx.type === "income" ? "Receita" : "Despesa")} · {formatDateShort(tx.date)}
                    </p>
                  </div>

                  {/* Amount */}
                  <div className={`text-sm font-bold tabular-nums ${tx.type === "income" ? "text-income" : "text-expense"}`}>
                    {tx.type === "income" ? "+" : "-"}{formatCurrency(Number(tx.amount))}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </div>

      {/* FAB */}
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.5, type: "spring", stiffness: 400, damping: 20 }}
        onClick={() => navigate("/transactions/new")}
        className="fixed bottom-24 right-5 w-14 h-14 rounded-full flex items-center justify-center btn-press glow-purple z-40"
        style={{
          background: "linear-gradient(135deg, oklch(0.65 0.22 295), oklch(0.55 0.22 250))",
          boxShadow: "0 8px 30px oklch(0.65 0.22 295 / 0.4)",
        }}
      >
        <Plus size={24} className="text-white" strokeWidth={2.5} />
      </motion.button>
    </AppLayout>
  );
}

function getCategoryEmoji(icon: string): string {
  const map: Record<string, string> = {
    "utensils": "🍽️", "car": "🚗", "home": "🏠", "heart": "❤️",
    "gamepad-2": "🎮", "book-open": "📚", "shopping-bag": "🛍️",
    "briefcase": "💼", "laptop": "💻", "trending-up": "📈",
    "more-horizontal": "⋯", "circle": "⭕", "target": "🎯",
    "star": "⭐", "zap": "⚡", "coffee": "☕", "music": "🎵",
    "plane": "✈️", "gift": "🎁", "phone": "📱",
  };
  return map[icon] ?? "💳";
}
