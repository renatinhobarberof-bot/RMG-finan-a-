import { useState, useEffect, useRef, useMemo } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { formatCurrency } from "@/hooks/useFinance";
import AppLayout from "@/components/AppLayout";
import { Sparkles, Send, TrendingDown, TrendingUp, AlertTriangle, Lightbulb, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export default function AIAssistant() {
  const [, navigate] = useLocation();
  const { user, loading: authLoading } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const now = new Date();
  const startDate = useMemo(() => new Date(now.getFullYear(), now.getMonth(), 1), []);
  const endDate = useMemo(() => new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59), []);

  const summary = trpc.transactions.summary.useQuery({ startDate, endDate });
  const spending = trpc.transactions.spendingByCategory.useQuery({ startDate, endDate });
  const insightsMutation = trpc.ai.insights.useMutation();
  const chatMutation = trpc.ai.chat.useMutation();

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  // Load initial insights
  useEffect(() => {
    if (summary.data && spending.data && messages.length === 0) {
      loadInsights();
    }
  }, [summary.data, spending.data]);

  const loadInsights = async () => {
    if (!summary.data) return;
    setIsTyping(true);
    try {
      const result = await insightsMutation.mutateAsync({
        income: summary.data.income,
        expense: summary.data.expense,
        balance: summary.data.balance,
        topCategories: spending.data?.slice(0, 5).map(c => ({
          name: c.categoryName ?? "Outros",
          total: Number(c.total ?? 0),
        })) ?? [],
      });

      const r = result as any;
      const msgContent = r.analysis
        ? `${r.analysis}\n\n💡 **Insights:**\n${(r.insights ?? []).map((s: string) => `• ${s}`).join("\n")}\n\n💰 **Recomendações:**\n${(r.recommendations ?? []).map((s: string) => `• ${s}`).join("\n")}${r.alerts?.length ? `\n\n⚠️ **Alertas:**\n${r.alerts.map((s: string) => `• ${s}`).join("\n")}` : ""}`
        : (r.message ?? r.reply ?? "Análise concluída! Como posso ajudar?");
      const welcomeMsg: Message = {
        role: "assistant",
        content: msgContent,
        timestamp: new Date(),
      };
      setMessages([welcomeMsg]);
    } catch {
      const fallback: Message = {
        role: "assistant",
        content: `Olá! Sou sua assistente financeira IA. 🤖✨\n\nAnalisei suas finanças deste mês:\n\n💰 **Receitas:** ${formatCurrency(summary.data?.income ?? 0)}\n💸 **Despesas:** ${formatCurrency(summary.data?.expense ?? 0)}\n📊 **Saldo:** ${formatCurrency(summary.data?.balance ?? 0)}\n\nComo posso te ajudar hoje? Pergunte sobre seus gastos, dicas de economia ou estratégias financeiras!`,
        timestamp: new Date(),
      };
      setMessages([fallback]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMsg: Message = { role: "user", content: input.trim(), timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    try {
      const result = await chatMutation.mutateAsync({
        message: input.trim(),
        context: {
          income: summary.data?.income ?? 0,
          expense: summary.data?.expense ?? 0,
          balance: summary.data?.balance ?? 0,
        },
      });

      const aiMsg: Message = { role: "assistant", content: result.reply, timestamp: new Date() };
      setMessages(prev => [...prev, aiMsg]);
    } catch {
      const errMsg: Message = {
        role: "assistant",
        content: "Desculpe, não consegui processar sua pergunta agora. Tente novamente em instantes.",
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const quickQuestions = [
    "Como posso economizar mais?",
    "Onde estou gastando mais?",
    "Dicas para investir",
    "Meu orçamento está saudável?",
  ];

  const insights = useMemo(() => {
    if (!summary.data || !spending.data) return [];
    const items = [];
    const savingsRate = summary.data.income > 0
      ? ((summary.data.income - summary.data.expense) / summary.data.income) * 100
      : 0;

    if (savingsRate < 10 && summary.data.income > 0) {
      items.push({
        icon: AlertTriangle,
        color: "oklch(0.62 0.22 25)",
        title: "Taxa de poupança baixa",
        desc: `Você está poupando apenas ${savingsRate.toFixed(0)}% da renda. O ideal é pelo menos 20%.`,
      });
    } else if (savingsRate >= 20) {
      items.push({
        icon: TrendingUp,
        color: "oklch(0.72 0.18 160)",
        title: "Ótima taxa de poupança!",
        desc: `Parabéns! Você está poupando ${savingsRate.toFixed(0)}% da renda este mês.`,
      });
    }

    const topCategory = spending.data[0];
    if (topCategory) {
      const pct = summary.data.expense > 0 ? (Number(topCategory.total ?? 0) / summary.data.expense) * 100 : 0;
      if (pct > 40) {
        items.push({
          icon: TrendingDown,
          color: "oklch(0.72 0.18 50)",
          title: `Alto gasto em ${topCategory.categoryName ?? "categoria"}`,
          desc: `${pct.toFixed(0)}% das despesas concentradas em uma categoria. Considere diversificar.`,
        });
      }
    }

    if (summary.data.balance < 0) {
      items.push({
        icon: AlertTriangle,
        color: "oklch(0.62 0.22 25)",
        title: "Saldo negativo",
        desc: "Suas despesas superaram as receitas este mês. Revise seus gastos urgentemente.",
      });
    }

    items.push({
      icon: Lightbulb,
      color: "oklch(0.65 0.22 295)",
      title: "Dica do mês",
      desc: "Regra 50/30/20: 50% para necessidades, 30% para desejos e 20% para poupança/investimentos.",
    });

    return items;
  }, [summary.data, spending.data]);

  return (
    <AppLayout>
      <div className="flex flex-col h-full px-5 pt-safe">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, oklch(0.65 0.22 295), oklch(0.55 0.22 250))" }}>
              <Sparkles size={20} className="text-white" />
            </div>
            <div>
              <h1 className="text-xl font-black text-foreground">IA Financeira</h1>
              <p className="text-muted-foreground text-xs">Assistente inteligente</p>
            </div>
          </div>
          <button onClick={loadInsights} className="w-9 h-9 rounded-xl bg-card border border-border/50 flex items-center justify-center btn-press">
            <RefreshCw size={16} className="text-muted-foreground" />
          </button>
        </motion.div>

        {/* Insights Cards */}
        {insights.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="flex gap-3 overflow-x-auto no-scrollbar pb-2 mb-4">
            {insights.map((insight, i) => (
              <motion.div key={i} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }}
                className="flex-shrink-0 w-64 bg-card border border-border/50 rounded-2xl p-3">
                <div className="flex items-center gap-2 mb-1.5">
                  <div className="w-7 h-7 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: `${insight.color}20` }}>
                    <insight.icon size={14} style={{ color: insight.color }} />
                  </div>
                  <p className="text-xs font-bold text-foreground">{insight.title}</p>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{insight.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto no-scrollbar space-y-3 mb-4 min-h-0">
          <AnimatePresence>
            {messages.map((msg, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {msg.role === "assistant" && (
                  <div className="w-7 h-7 rounded-xl flex items-center justify-center mr-2 mt-1 flex-shrink-0"
                    style={{ background: "linear-gradient(135deg, oklch(0.65 0.22 295), oklch(0.55 0.22 250))" }}>
                    <Sparkles size={14} className="text-white" />
                  </div>
                )}
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                    msg.role === "user"
                      ? "text-white rounded-br-md"
                      : "bg-card border border-border/50 text-foreground rounded-bl-md"
                  }`}
                  style={msg.role === "user" ? {
                    background: "linear-gradient(135deg, oklch(0.65 0.22 295), oklch(0.55 0.22 250))"
                  } : {}}
                >
                  {msg.content}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Typing indicator */}
          {isTyping && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl flex items-center justify-center"
                style={{ background: "linear-gradient(135deg, oklch(0.65 0.22 295), oklch(0.55 0.22 250))" }}>
                <Sparkles size={14} className="text-white" />
              </div>
              <div className="bg-card border border-border/50 rounded-2xl rounded-bl-md px-4 py-3">
                <div className="flex gap-1">
                  {[0, 1, 2].map(i => (
                    <motion.div key={i} animate={{ y: [0, -4, 0] }}
                      transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
                      className="w-1.5 h-1.5 rounded-full bg-primary" />
                  ))}
                </div>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Questions */}
        {messages.length <= 1 && !isTyping && (
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 mb-3">
            {quickQuestions.map((q, i) => (
              <button key={i} onClick={() => { setInput(q); }}
                className="flex-shrink-0 px-3 py-2 rounded-xl bg-card border border-border/50 text-xs font-medium text-foreground btn-press">
                {q}
              </button>
            ))}
          </div>
        )}

        {/* Input */}
        <div className="flex gap-2 pb-safe pb-4">
          <Input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleSend()}
            placeholder="Pergunte sobre suas finanças..."
            className="flex-1 bg-card border-border/50 rounded-2xl h-12"
          />
          <Button
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            className="w-12 h-12 rounded-2xl flex-shrink-0 btn-press"
            style={{ background: "linear-gradient(135deg, oklch(0.65 0.22 295), oklch(0.55 0.22 250))" }}
          >
            <Send size={18} className="text-white" />
          </Button>
        </div>
      </div>
    </AppLayout>
  );
}
