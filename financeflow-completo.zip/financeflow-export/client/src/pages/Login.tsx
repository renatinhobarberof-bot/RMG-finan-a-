import { useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Sparkles, Shield, TrendingUp, ArrowRight } from "lucide-react";

export default function Login() {
  const [, navigate] = useLocation();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading && user) navigate("/home");
  }, [user, loading, navigate]);

  const handleLogin = () => {
    window.location.href = getLoginUrl();
  };

  const features = [
    { icon: TrendingUp, text: "Controle total das finanças", color: "oklch(0.52 0.22 170)" },
    { icon: Shield, text: "Dados seguros e criptografados", color: "oklch(0.72 0.18 160)" },
    { icon: Sparkles, text: "IA financeira personalizada", color: "oklch(0.72 0.18 50)" },
  ];

  return (
    <div className="min-h-dvh bg-background flex flex-col relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 rounded-full opacity-20"
          style={{ background: "radial-gradient(circle, oklch(0.65 0.22 295), transparent 70%)" }} />
        <div className="absolute -bottom-20 -left-20 w-60 h-60 rounded-full opacity-10"
          style={{ background: "radial-gradient(circle, oklch(0.72 0.18 160), transparent 70%)" }} />
        {/* Grid pattern */}
        <div className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: "linear-gradient(oklch(1 0 0) 1px, transparent 1px), linear-gradient(90deg, oklch(1 0 0) 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }} />
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col justify-between px-6 pt-safe relative z-10">
        {/* Top section */}
        <div className="pt-12 flex flex-col items-center gap-8">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
            className="flex flex-col items-center gap-4"
          >
            <motion.div
              animate={{ boxShadow: ["0 0 20px oklch(0.52 0.22 170 / 0.3)", "0 0 40px oklch(0.52 0.22 170 / 0.5)", "0 0 20px oklch(0.52 0.22 170 / 0.3)"] }}
              transition={{ duration: 2.5, repeat: Infinity }}
              className="w-20 h-20 rounded-2xl flex items-center justify-center border-2 border-emerald-400/30"
              style={{ background: "linear-gradient(135deg, oklch(0.2 0.08 170), oklch(0.15 0.08 170))" }}
            >
              <span className="text-3xl font-black text-emerald-400">R</span>
            </motion.div>
            <div className="text-center">
              <h1 className="text-2xl font-black text-emerald-400">RMG Finança</h1>
              <p className="text-muted-foreground text-sm">Gestão Financeira Inteligente</p>
            </div>
          </motion.div>

          {/* Headline */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="text-center space-y-2"
          >
            <h2 className="text-3xl font-black text-foreground leading-tight">
              Suas finanças,
              <br />
              <span className="gradient-text">sob controle.</span>
            </h2>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Gerencie receitas, despesas e metas com inteligência artificial.
            </p>
          </motion.div>

          {/* Features */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35, duration: 0.5 }}
            className="w-full space-y-3"
          >
            {features.map((f, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 + i * 0.1 }}
                className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border/50"
              >
                <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: `${f.color}20` }}>
                  <f.icon size={18} style={{ color: f.color }} />
                </div>
                <span className="text-sm font-medium text-foreground">{f.text}</span>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.5 }}
          className="pb-safe pb-10 space-y-4"
        >
          <Button
            onClick={handleLogin}
            size="lg"
            className="w-full h-14 text-base font-bold rounded-2xl btn-press glow-emerald"
            style={{
              background: "linear-gradient(135deg, oklch(0.52 0.22 170), oklch(0.45 0.22 160))",
            }}
          >
            <span className="flex items-center gap-2">
              Entrar com Manus
              <ArrowRight size={20} />
            </span>
          </Button>

          <p className="text-center text-xs text-muted-foreground leading-relaxed">
            Ao continuar, você concorda com nossos{" "}
            <span className="text-primary">Termos de Uso</span> e{" "}
            <span className="text-primary">Política de Privacidade</span>
          </p>
        </motion.div>
      </div>
    </div>
  );
}
