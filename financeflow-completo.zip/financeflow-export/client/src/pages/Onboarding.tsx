import { useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronRight, BarChart3, Shield, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

const slides = [
  {
    icon: BarChart3,
    color: "oklch(0.65 0.22 295)",
    title: "Controle Total",
    subtitle: "das suas finanças",
    description: "Acompanhe receitas, despesas e saldo em tempo real com gráficos interativos e insights detalhados.",
    bg: "from-purple-500/20 to-transparent",
  },
  {
    icon: Shield,
    color: "oklch(0.72 0.18 160)",
    title: "Orçamentos",
    subtitle: "inteligentes",
    description: "Defina limites por categoria, receba alertas antes de estourar o orçamento e alcance suas metas.",
    bg: "from-emerald-500/20 to-transparent",
  },
  {
    icon: Sparkles,
    color: "oklch(0.72 0.18 50)",
    title: "IA Financeira",
    subtitle: "personalizada",
    description: "Receba sugestões automáticas, insights personalizados e recomendações de economia baseadas no seu perfil.",
    bg: "from-amber-500/20 to-transparent",
  },
];

export default function Onboarding() {
  const [current, setCurrent] = useState(0);
  const [, navigate] = useLocation();

  const next = () => {
    if (current < slides.length - 1) setCurrent(current + 1);
    else navigate("/login");
  };

  const skip = () => navigate("/login");

  const slide = slides[current];
  const Icon = slide.icon;

  return (
    <div className="min-h-dvh bg-background flex flex-col relative overflow-hidden">
      {/* Background gradient */}
      <AnimatePresence mode="wait">
        <motion.div
          key={current}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className={`absolute inset-0 bg-gradient-radial ${slide.bg} pointer-events-none`}
          style={{
            background: `radial-gradient(ellipse at 50% 30%, ${slide.color}20 0%, transparent 60%)`,
          }}
        />
      </AnimatePresence>

      {/* Skip button */}
      <div className="flex justify-end p-6 pt-safe relative z-10">
        {current < slides.length - 1 && (
          <button onClick={skip} className="text-muted-foreground text-sm font-medium hover:text-foreground transition-colors">
            Pular
          </button>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-8 relative z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={current}
            initial={{ opacity: 0, x: 60 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -60 }}
            transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
            className="flex flex-col items-center text-center gap-8"
          >
            {/* Icon */}
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="w-28 h-28 rounded-3xl flex items-center justify-center"
              style={{
                background: `linear-gradient(135deg, ${slide.color}30, ${slide.color}10)`,
                border: `1px solid ${slide.color}30`,
              }}
            >
              <Icon size={52} style={{ color: slide.color }} strokeWidth={1.5} />
            </motion.div>

            {/* Text */}
            <div className="space-y-2">
              <h2 className="text-4xl font-black text-foreground leading-tight">
                {slide.title}
                <br />
                <span style={{ color: slide.color }}>{slide.subtitle}</span>
              </h2>
              <p className="text-muted-foreground text-base leading-relaxed max-w-xs">
                {slide.description}
              </p>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom */}
      <div className="px-8 pb-safe pb-10 flex flex-col gap-6 relative z-10">
        {/* Dots */}
        <div className="flex justify-center gap-2">
          {slides.map((_, i) => (
            <motion.button
              key={i}
              onClick={() => setCurrent(i)}
              animate={{ width: i === current ? 24 : 8 }}
              transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
              className="h-2 rounded-full transition-colors"
              style={{ backgroundColor: i === current ? slide.color : "oklch(0.3 0.01 270)" }}
            />
          ))}
        </div>

        {/* CTA Button */}
        <Button
          onClick={next}
          size="lg"
          className="w-full h-14 text-base font-bold rounded-2xl btn-press"
          style={{
            background: `linear-gradient(135deg, ${slide.color}, ${slide.color}cc)`,
            boxShadow: `0 8px 30px ${slide.color}40`,
          }}
        >
          {current < slides.length - 1 ? (
            <span className="flex items-center gap-2">
              Próximo <ChevronRight size={20} />
            </span>
          ) : (
            "Começar Agora"
          )}
        </Button>
      </div>
    </div>
  );
}
