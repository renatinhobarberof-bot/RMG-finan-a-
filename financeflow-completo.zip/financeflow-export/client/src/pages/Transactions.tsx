import { useState, useEffect, useMemo } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { formatCurrency, formatDateShort } from "@/hooks/useFinance";
import AppLayout from "@/components/AppLayout";
import { Search, Plus, Filter, X, ChevronDown, Trash2, Edit2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

type FilterType = "all" | "income" | "expense";

export default function Transactions() {
  const [, navigate] = useLocation();
  const { user, loading: authLoading } = useAuth();
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState<FilterType>("all");
  const [filterCategory, setFilterCategory] = useState<number | undefined>();
  const [showFilters, setShowFilters] = useState(false);
  const [page, setPage] = useState(0);
  const LIMIT = 20;

  const categories = trpc.categories.list.useQuery();
  const utils = trpc.useUtils();

  const queryInput = useMemo(() => ({
    limit: LIMIT,
    offset: page * LIMIT,
    type: filterType !== "all" ? filterType as "income" | "expense" : undefined,
    categoryId: filterCategory,
    search: search || undefined,
  }), [page, filterType, filterCategory, search]);

  const txQuery = trpc.transactions.list.useQuery(queryInput);

  const deleteMutation = trpc.transactions.delete.useMutation({
    onSuccess: () => {
      utils.transactions.list.invalidate();
      utils.transactions.summary.invalidate();
      toast.success("Transação excluída");
    },
    onError: () => toast.error("Erro ao excluir transação"),
  });

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  // Reset page on filter change
  useEffect(() => { setPage(0); }, [search, filterType, filterCategory]);

  const hasFilters = filterType !== "all" || filterCategory !== undefined || search !== "";

  return (
    <AppLayout>
      <div className="px-5 pt-safe">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="py-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-black text-foreground">Transações</h1>
              {txQuery.data && (
                <p className="text-muted-foreground text-sm">{txQuery.data.total} registros</p>
              )}
            </div>
            <Button
              size="sm"
              onClick={() => navigate("/transactions/new")}
              className="rounded-xl btn-press"
              style={{ background: "linear-gradient(135deg, oklch(0.65 0.22 295), oklch(0.55 0.22 250))" }}
            >
              <Plus size={16} className="mr-1" /> Nova
            </Button>
          </div>

          {/* Search */}
          <div className="relative mb-3">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar transações..."
              className="pl-10 pr-10 bg-card border-border/50 rounded-xl h-11"
            />
            {search && (
              <button onClick={() => setSearch("")} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground">
                <X size={14} />
              </button>
            )}
          </div>

          {/* Filter chips */}
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {(["all", "income", "expense"] as FilterType[]).map((type) => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 ${
                  filterType === type
                    ? "bg-primary text-white"
                    : "bg-card border border-border/50 text-muted-foreground"
                }`}
              >
                {type === "all" ? "Todos" : type === "income" ? "Receitas" : "Despesas"}
              </button>
            ))}
            <button
              onClick={() => setShowFilters(true)}
              className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                filterCategory ? "bg-primary text-white" : "bg-card border border-border/50 text-muted-foreground"
              }`}
            >
              <Filter size={12} /> Categoria
            </button>
            {hasFilters && (
              <button
                onClick={() => { setFilterType("all"); setFilterCategory(undefined); setSearch(""); }}
                className="flex-shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold bg-destructive/20 text-destructive border border-destructive/30"
              >
                <X size={12} /> Limpar
              </button>
            )}
          </div>
        </motion.div>

        {/* Transaction List */}
        {txQuery.isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-16 w-full rounded-2xl" />)}
          </div>
        ) : txQuery.data?.items.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center py-16 text-center"
          >
            <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mb-4">
              <Search size={28} className="text-muted-foreground" />
            </div>
            <p className="text-foreground font-semibold mb-1">Nenhuma transação encontrada</p>
            <p className="text-muted-foreground text-sm">Tente ajustar os filtros ou adicione uma nova transação</p>
          </motion.div>
        ) : (
          <div className="space-y-2 mb-6">
            <AnimatePresence>
              {txQuery.data?.items.map((tx, i) => (
                <motion.div
                  key={tx.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  transition={{ delay: i * 0.03 }}
                  className="flex items-center gap-3 p-3.5 bg-card border border-border/50 rounded-2xl"
                >
                  {/* Icon */}
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center text-lg flex-shrink-0"
                    style={{ backgroundColor: `${tx.categoryColor ?? "#8B5CF6"}20` }}
                  >
                    {getCategoryEmoji(tx.categoryIcon ?? "")}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground truncate">{tx.description}</p>
                    <p className="text-xs text-muted-foreground">
                      {tx.categoryName ?? (tx.type === "income" ? "Receita" : "Despesa")} · {formatDateShort(tx.date)}
                    </p>
                  </div>

                  {/* Amount + Actions */}
                  <div className="flex items-center gap-2">
                    <p className={`text-sm font-bold tabular-nums ${tx.type === "income" ? "text-income" : "text-expense"}`}>
                      {tx.type === "income" ? "+" : "-"}{formatCurrency(Number(tx.amount))}
                    </p>
                    <div className="flex gap-1">
                      <button
                        onClick={() => navigate(`/transactions/${tx.id}/edit`)}
                        className="w-7 h-7 rounded-lg bg-secondary flex items-center justify-center btn-press"
                      >
                        <Edit2 size={12} className="text-muted-foreground" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm("Excluir esta transação?")) {
                            deleteMutation.mutate({ id: tx.id });
                          }
                        }}
                        className="w-7 h-7 rounded-lg bg-destructive/10 flex items-center justify-center btn-press"
                      >
                        <Trash2 size={12} className="text-destructive" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Pagination */}
            {txQuery.data && txQuery.data.total > LIMIT && (
              <div className="flex justify-center gap-3 pt-4">
                <Button variant="outline" size="sm" disabled={page === 0} onClick={() => setPage(p => p - 1)}>
                  Anterior
                </Button>
                <span className="text-sm text-muted-foreground py-1.5">
                  {page + 1} / {Math.ceil(txQuery.data.total / LIMIT)}
                </span>
                <Button variant="outline" size="sm" disabled={(page + 1) * LIMIT >= txQuery.data.total} onClick={() => setPage(p => p + 1)}>
                  Próxima
                </Button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Filter Sheet */}
      <Sheet open={showFilters} onOpenChange={setShowFilters}>
        <SheetContent side="bottom" className="rounded-t-3xl bg-card border-border/50">
          <SheetHeader className="mb-4">
            <SheetTitle>Filtrar por Categoria</SheetTitle>
          </SheetHeader>
          <div className="grid grid-cols-3 gap-2 pb-safe pb-6">
            <button
              onClick={() => { setFilterCategory(undefined); setShowFilters(false); }}
              className={`p-3 rounded-xl text-xs font-semibold text-center transition-all ${
                !filterCategory ? "bg-primary text-white" : "bg-secondary text-foreground"
              }`}
            >
              Todas
            </button>
            {categories.data?.map((cat) => (
              <button
                key={cat.id}
                onClick={() => { setFilterCategory(cat.id); setShowFilters(false); }}
                className={`p-3 rounded-xl text-xs font-semibold text-center transition-all ${
                  filterCategory === cat.id ? "bg-primary text-white" : "bg-secondary text-foreground"
                }`}
              >
                <div className="text-lg mb-1">{getCategoryEmoji(cat.icon)}</div>
                {cat.name}
              </button>
            ))}
          </div>
        </SheetContent>
      </Sheet>
    </AppLayout>
  );
}

function getCategoryEmoji(icon: string): string {
  const map: Record<string, string> = {
    "utensils": "🍽️", "car": "🚗", "home": "🏠", "heart": "❤️",
    "gamepad-2": "🎮", "book-open": "📚", "shopping-bag": "🛍️",
    "briefcase": "💼", "laptop": "💻", "trending-up": "📈",
    "more-horizontal": "⋯", "circle": "⭕", "target": "🎯",
  };
  return map[icon] ?? "💳";
}
