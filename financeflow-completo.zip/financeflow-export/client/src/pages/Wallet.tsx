import { useEffect, useMemo } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { formatCurrency } from "@/hooks/useFinance";
import AppLayout from "@/components/AppLayout";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
import { Target, Plus, TrendingUp, TrendingDown, Wallet as WalletIcon, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";

export default function Wallet() {
  const [, navigate] = useLocation();
  const { user, loading: authLoading } = useAuth();

  const now = new Date();
  const startDate = useMemo(() => new Date(now.getFullYear(), now.getMonth(), 1), []);
  const endDate = useMemo(() => new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59), []);

  const summary = trpc.transactions.summary.useQuery({ startDate, endDate });
  const goals = trpc.goals.list.useQuery();
  const budgets = trpc.budgets.list.useQuery({ month: now.getMonth() + 1, year: now.getFullYear() });

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  const balance = summary.data?.balance ?? 0;
  const income = summary.data?.income ?? 0;
  const expense = summary.data?.expense ?? 0;
  const savingsRate = income > 0 ? ((income - expense) / income) * 100 : 0;

  return (
    <AppLayout>
      <div className="px-5 pt-safe">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="py-5">
          <h1 className="text-2xl font-black text-foreground">Carteira</h1>
          <p className="text-muted-foreground text-sm">Visão geral das suas finanças</p>
        </motion.div>

        {/* Summary Cards */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="grid grid-cols-2 gap-3 mb-5">
          {[
            { label: "Receitas", value: income, icon: TrendingUp, color: "oklch(0.72 0.18 160)", bg: "bg-income" },
            { label: "Despesas", value: expense, icon: TrendingDown, color: "oklch(0.62 0.22 25)", bg: "bg-expense" },
          ].map((item) => (
            <div key={item.label} className="bg-card border border-border/50 rounded-2xl p-4">
              <div className={`w-9 h-9 rounded-xl ${item.bg} flex items-center justify-center mb-3`}>
                <item.icon size={18} style={{ color: item.color }} />
              </div>
              <p className="text-muted-foreground text-xs mb-1">{item.label}</p>
              {summary.isLoading ? (
                <Skeleton className="h-5 w-20" />
              ) : (
                <p className="font-bold text-sm text-foreground tabular-nums">{formatCurrency(item.value)}</p>
              )}
            </div>
          ))}
        </motion.div>

        {/* Savings Rate */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
          className="bg-card border border-border/50 rounded-3xl p-5 mb-5">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <h3 className="text-sm font-bold text-foreground mb-1">Taxa de Poupança</h3>
              <p className="text-muted-foreground text-xs mb-3">Quanto você está guardando este mês</p>
              <div className="flex items-end gap-2">
                <span className="text-3xl font-black text-foreground">{savingsRate.toFixed(0)}%</span>
                <span className="text-muted-foreground text-sm mb-1">do rendimento</span>
              </div>
              <Progress value={Math.max(0, savingsRate)} className="mt-3 h-2" />
            </div>
            <div className="w-20 h-20 ml-4">
              <CircularProgressbar
                value={Math.max(0, Math.min(100, savingsRate))}
                text={`${savingsRate.toFixed(0)}%`}
                styles={buildStyles({
                  textSize: "22px",
                  pathColor: "oklch(0.65 0.22 295)",
                  textColor: "oklch(0.97 0.005 270)",
                  trailColor: "oklch(0.22 0.02 270)",
                  pathTransitionDuration: 0.8,
                })}
              />
            </div>
          </div>
        </motion.div>

        {/* Goals */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mb-5">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-foreground">Metas Financeiras</h2>
            <button onClick={() => navigate("/budget")} className="flex items-center gap-1 text-xs text-primary font-semibold">
              Ver todas <ChevronRight size={14} />
            </button>
          </div>

          {goals.isLoading ? (
            <div className="space-y-3">
              {[1, 2].map((i) => <Skeleton key={i} className="h-20 w-full rounded-2xl" />)}
            </div>
          ) : goals.data?.length === 0 ? (
            <div className="bg-card border border-border/50 rounded-2xl p-6 text-center">
              <Target size={28} className="mx-auto mb-2 text-muted-foreground" />
              <p className="text-muted-foreground text-sm mb-3">Nenhuma meta criada</p>
              <Button size="sm" onClick={() => navigate("/budget")}>
                <Plus size={14} className="mr-1" /> Criar meta
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {goals.data?.slice(0, 3).map((goal, i) => {
                const current = Number(goal.currentAmount);
                const target = Number(goal.targetAmount);
                const pct = target > 0 ? Math.min((current / target) * 100, 100) : 0;
                return (
                  <motion.div
                    key={goal.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.08 }}
                    className="bg-card border border-border/50 rounded-2xl p-4"
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg"
                        style={{ backgroundColor: `${goal.color}20` }}>
                        🎯
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-foreground truncate">{goal.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {formatCurrency(current)} de {formatCurrency(target)}
                        </p>
                      </div>
                      <span className="text-xs font-bold" style={{ color: goal.color }}>{pct.toFixed(0)}%</span>
                    </div>
                    <Progress value={pct} className="h-1.5"
                      style={{ "--progress-color": goal.color } as any} />
                  </motion.div>
                );
              })}
            </div>
          )}
        </motion.div>

        {/* Budget Overview */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }} className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-foreground">Orçamentos do Mês</h2>
            <button onClick={() => navigate("/budget")} className="flex items-center gap-1 text-xs text-primary font-semibold">
              Gerenciar <ChevronRight size={14} />
            </button>
          </div>

          {budgets.isLoading ? (
            <div className="space-y-3">
              {[1, 2].map((i) => <Skeleton key={i} className="h-16 w-full rounded-2xl" />)}
            </div>
          ) : budgets.data?.length === 0 ? (
            <div className="bg-card border border-border/50 rounded-2xl p-6 text-center">
              <WalletIcon size={28} className="mx-auto mb-2 text-muted-foreground" />
              <p className="text-muted-foreground text-sm mb-3">Nenhum orçamento definido</p>
              <Button size="sm" onClick={() => navigate("/budget")}>
                <Plus size={14} className="mr-1" /> Criar orçamento
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {budgets.data?.slice(0, 4).map((budget, i) => {
                const pct = budget.percentage ?? 0;
                const isOver = pct >= 100;
                const isAlert = pct >= (budget.alertThreshold ?? 80);
                const color = isOver ? "oklch(0.62 0.22 25)" : isAlert ? "oklch(0.72 0.18 50)" : "oklch(0.65 0.22 295)";
                return (
                  <motion.div
                    key={budget.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.08 }}
                    className="bg-card border border-border/50 rounded-2xl p-4"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-base">{budget.categoryIcon ? getCategoryEmoji(budget.categoryIcon) : "💰"}</span>
                        <p className="text-sm font-semibold text-foreground">{budget.name}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs font-bold" style={{ color }}>
                          {formatCurrency(budget.spent)} / {formatCurrency(Number(budget.limitAmount))}
                        </p>
                      </div>
                    </div>
                    <div className="relative h-2 bg-secondary rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1], delay: i * 0.1 }}
                        className="absolute inset-y-0 left-0 rounded-full"
                        style={{ backgroundColor: color }}
                      />
                    </div>
                    {isAlert && !isOver && (
                      <p className="text-xs mt-1.5" style={{ color: "oklch(0.72 0.18 50)" }}>
                        ⚠️ {pct.toFixed(0)}% do limite utilizado
                      </p>
                    )}
                    {isOver && (
                      <p className="text-xs mt-1.5 text-expense">🚨 Limite ultrapassado!</p>
                    )}
                  </motion.div>
                );
              })}
            </div>
          )}
        </motion.div>
      </div>
    </AppLayout>
  );
}

function getCategoryEmoji(icon: string): string {
  const map: Record<string, string> = {
    "utensils": "🍽️", "car": "🚗", "home": "🏠", "heart": "❤️",
    "gamepad-2": "🎮", "book-open": "📚", "shopping-bag": "🛍️",
    "briefcase": "💼", "laptop": "💻", "trending-up": "📈",
    "more-horizontal": "⋯", "circle": "⭕", "target": "🎯",
  };
  return map[icon] ?? "💳";
}
