import { useState, useEffect, useMemo } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { formatCurrency } from "@/hooks/useFinance";
import AppLayout from "@/components/AppLayout";
import { Plus, Target, Wallet, Trash2, ChevronLeft, ChevronRight, Edit2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Budget() {
  const [, navigate] = useLocation();
  const { user, loading: authLoading } = useAuth();
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [showBudgetSheet, setShowBudgetSheet] = useState(false);
  const [showGoalSheet, setShowGoalSheet] = useState(false);
  const [editingBudget, setEditingBudget] = useState<any>(null);
  const [editingGoal, setEditingGoal] = useState<any>(null);

  // Budget form
  const [budgetName, setBudgetName] = useState("");
  const [budgetLimit, setBudgetLimit] = useState("");
  const [budgetCategoryId, setBudgetCategoryId] = useState<string>("");
  const [budgetAlert, setBudgetAlert] = useState("80");

  // Goal form
  const [goalName, setGoalName] = useState("");
  const [goalTarget, setGoalTarget] = useState("");
  const [goalCurrent, setGoalCurrent] = useState("0");
  const [goalDeadline, setGoalDeadline] = useState("");

  const utils = trpc.useUtils();
  const categories = trpc.categories.list.useQuery();
  const budgets = trpc.budgets.list.useQuery({ month, year });
  const goals = trpc.goals.list.useQuery();

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  const createBudget = trpc.budgets.create.useMutation({
    onSuccess: () => { utils.budgets.list.invalidate(); setShowBudgetSheet(false); resetBudgetForm(); toast.success("Orçamento criado!"); },
    onError: (e) => toast.error(e.message),
  });

  const updateBudget = trpc.budgets.update.useMutation({
    onSuccess: () => { utils.budgets.list.invalidate(); setShowBudgetSheet(false); resetBudgetForm(); toast.success("Orçamento atualizado!"); },
    onError: (e) => toast.error(e.message),
  });

  const deleteBudget = trpc.budgets.delete.useMutation({
    onSuccess: () => { utils.budgets.list.invalidate(); toast.success("Orçamento excluído"); },
  });

  const createGoal = trpc.goals.create.useMutation({
    onSuccess: () => { utils.goals.list.invalidate(); setShowGoalSheet(false); resetGoalForm(); toast.success("Meta criada!"); },
    onError: (e) => toast.error(e.message),
  });

  const updateGoal = trpc.goals.update.useMutation({
    onSuccess: () => { utils.goals.list.invalidate(); setShowGoalSheet(false); resetGoalForm(); toast.success("Meta atualizada!"); },
    onError: (e) => toast.error(e.message),
  });

  const deleteGoal = trpc.goals.delete.useMutation({
    onSuccess: () => { utils.goals.list.invalidate(); toast.success("Meta excluída"); },
  });

  const resetBudgetForm = () => { setBudgetName(""); setBudgetLimit(""); setBudgetCategoryId(""); setBudgetAlert("80"); setEditingBudget(null); };
  const resetGoalForm = () => { setGoalName(""); setGoalTarget(""); setGoalCurrent("0"); setGoalDeadline(""); setEditingGoal(null); };

  const handleSaveBudget = () => {
    if (!budgetName || !budgetLimit) { toast.error("Preencha todos os campos"); return; }
    const data = {
      name: budgetName,
      limitAmount: budgetLimit,
      categoryId: budgetCategoryId ? Number(budgetCategoryId) : undefined,
      alertThreshold: Number(budgetAlert),
      alertEnabled: true,
      month,
      year,
    };
    if (editingBudget) updateBudget.mutate({ id: editingBudget.id, ...data });
    else createBudget.mutate(data);
  };

  const handleSaveGoal = () => {
    if (!goalName || !goalTarget) { toast.error("Preencha todos os campos"); return; }
    const data = {
      name: goalName,
      targetAmount: goalTarget,
      currentAmount: goalCurrent || "0",
      deadline: goalDeadline ? new Date(goalDeadline) : undefined,
    };
    if (editingGoal) updateGoal.mutate({ id: editingGoal.id, ...data });
    else createGoal.mutate(data);
  };

  const monthName = new Date(year, month - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });

  return (
    <AppLayout>
      <div className="px-5 pt-safe">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="py-5">
          <h1 className="text-2xl font-black text-foreground">Orçamento</h1>
          <p className="text-muted-foreground text-sm">Controle seus limites e metas</p>
        </motion.div>

        <Tabs defaultValue="budgets">
          <TabsList className="w-full mb-5 bg-card border border-border/50 rounded-2xl p-1 h-12">
            <TabsTrigger value="budgets" className="flex-1 rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white">
              <Wallet size={14} className="mr-1.5" /> Orçamentos
            </TabsTrigger>
            <TabsTrigger value="goals" className="flex-1 rounded-xl data-[state=active]:bg-primary data-[state=active]:text-white">
              <Target size={14} className="mr-1.5" /> Metas
            </TabsTrigger>
          </TabsList>

          {/* BUDGETS TAB */}
          <TabsContent value="budgets">
            {/* Month Navigation */}
            <div className="flex items-center justify-between mb-4">
              <button onClick={() => { if (month === 1) { setMonth(12); setYear(y => y - 1); } else setMonth(m => m - 1); }}
                className="w-9 h-9 rounded-xl bg-card border border-border/50 flex items-center justify-center btn-press">
                <ChevronLeft size={18} />
              </button>
              <span className="text-sm font-bold text-foreground capitalize">{monthName}</span>
              <button onClick={() => { if (month === 12) { setMonth(1); setYear(y => y + 1); } else setMonth(m => m + 1); }}
                className="w-9 h-9 rounded-xl bg-card border border-border/50 flex items-center justify-center btn-press">
                <ChevronRight size={18} />
              </button>
            </div>

            <Button onClick={() => { resetBudgetForm(); setShowBudgetSheet(true); }}
              className="w-full h-12 rounded-2xl mb-4 btn-press"
              style={{ background: "linear-gradient(135deg, oklch(0.65 0.22 295), oklch(0.55 0.22 250))" }}>
              <Plus size={18} className="mr-2" /> Novo Orçamento
            </Button>

            {budgets.isLoading ? (
              <div className="space-y-3">{[1, 2, 3].map(i => <Skeleton key={i} className="h-24 rounded-2xl" />)}</div>
            ) : budgets.data?.length === 0 ? (
              <div className="text-center py-12">
                <Wallet size={40} className="mx-auto mb-3 text-muted-foreground" />
                <p className="text-muted-foreground">Nenhum orçamento para este mês</p>
              </div>
            ) : (
              <div className="space-y-3">
                {budgets.data?.map((b, i) => {
                  const pct = b.percentage ?? 0;
                  const isOver = pct >= 100;
                  const isAlert = pct >= (b.alertThreshold ?? 80);
                  const color = isOver ? "oklch(0.62 0.22 25)" : isAlert ? "oklch(0.72 0.18 50)" : "oklch(0.65 0.22 295)";
                  return (
                    <motion.div key={b.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                      className="bg-card border border-border/50 rounded-2xl p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{b.categoryIcon ? getCategoryEmoji(b.categoryIcon) : "💰"}</span>
                          <div>
                            <p className="text-sm font-bold text-foreground">{b.name}</p>
                            <p className="text-xs text-muted-foreground">{b.categoryName ?? "Geral"}</p>
                          </div>
                        </div>
                        <div className="flex gap-1.5">
                          <button onClick={() => { setEditingBudget(b); setBudgetName(b.name); setBudgetLimit(String(b.limitAmount)); setBudgetCategoryId(b.categoryId ? String(b.categoryId) : ""); setBudgetAlert(String(b.alertThreshold)); setShowBudgetSheet(true); }}
                            className="w-7 h-7 rounded-lg bg-secondary flex items-center justify-center btn-press">
                            <Edit2 size={12} className="text-muted-foreground" />
                          </button>
                          <button onClick={() => { if (confirm("Excluir orçamento?")) deleteBudget.mutate({ id: b.id }); }}
                            className="w-7 h-7 rounded-lg bg-destructive/10 flex items-center justify-center btn-press">
                            <Trash2 size={12} className="text-destructive" />
                          </button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between text-xs mb-2">
                        <span className="text-muted-foreground">Gasto: {formatCurrency(b.spent)}</span>
                        <span style={{ color }} className="font-bold">{pct.toFixed(0)}% de {formatCurrency(Number(b.limitAmount))}</span>
                      </div>
                      <div className="relative h-2.5 bg-secondary rounded-full overflow-hidden">
                        <motion.div initial={{ width: 0 }} animate={{ width: `${Math.min(pct, 100)}%` }}
                          transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1], delay: i * 0.1 }}
                          className="absolute inset-y-0 left-0 rounded-full"
                          style={{ backgroundColor: color }} />
                      </div>
                      {isOver && <p className="text-xs text-expense mt-1.5">🚨 Limite ultrapassado em {formatCurrency(b.spent - Number(b.limitAmount))}</p>}
                      {isAlert && !isOver && <p className="text-xs mt-1.5" style={{ color: "oklch(0.72 0.18 50)" }}>⚠️ Atenção: {pct.toFixed(0)}% do limite utilizado</p>}
                    </motion.div>
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* GOALS TAB */}
          <TabsContent value="goals">
            <Button onClick={() => { resetGoalForm(); setShowGoalSheet(true); }}
              className="w-full h-12 rounded-2xl mb-4 btn-press"
              style={{ background: "linear-gradient(135deg, oklch(0.65 0.22 295), oklch(0.55 0.22 250))" }}>
              <Plus size={18} className="mr-2" /> Nova Meta
            </Button>

            {goals.isLoading ? (
              <div className="space-y-3">{[1, 2].map(i => <Skeleton key={i} className="h-28 rounded-2xl" />)}</div>
            ) : goals.data?.length === 0 ? (
              <div className="text-center py-12">
                <Target size={40} className="mx-auto mb-3 text-muted-foreground" />
                <p className="text-muted-foreground">Nenhuma meta criada ainda</p>
              </div>
            ) : (
              <div className="space-y-3">
                {goals.data?.map((g, i) => {
                  const current = Number(g.currentAmount);
                  const target = Number(g.targetAmount);
                  const pct = target > 0 ? Math.min((current / target) * 100, 100) : 0;
                  const remaining = target - current;
                  return (
                    <motion.div key={g.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                      className="bg-card border border-border/50 rounded-2xl p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-11 h-11 rounded-xl flex items-center justify-center text-xl"
                            style={{ backgroundColor: `${g.color}20` }}>🎯</div>
                          <div>
                            <p className="text-sm font-bold text-foreground">{g.name}</p>
                            {g.deadline && (
                              <p className="text-xs text-muted-foreground">
                                Prazo: {new Date(g.deadline).toLocaleDateString("pt-BR")}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="flex gap-1.5">
                          <button onClick={() => { setEditingGoal(g); setGoalName(g.name); setGoalTarget(String(g.targetAmount)); setGoalCurrent(String(g.currentAmount)); setGoalDeadline(g.deadline ? new Date(g.deadline).toISOString().split("T")[0] : ""); setShowGoalSheet(true); }}
                            className="w-7 h-7 rounded-lg bg-secondary flex items-center justify-center btn-press">
                            <Edit2 size={12} className="text-muted-foreground" />
                          </button>
                          <button onClick={() => { if (confirm("Excluir meta?")) deleteGoal.mutate({ id: g.id }); }}
                            className="w-7 h-7 rounded-lg bg-destructive/10 flex items-center justify-center btn-press">
                            <Trash2 size={12} className="text-destructive" />
                          </button>
                        </div>
                      </div>
                      <div className="flex justify-between text-xs mb-2">
                        <span className="text-muted-foreground">{formatCurrency(current)} guardados</span>
                        <span className="font-bold" style={{ color: g.color }}>{pct.toFixed(0)}%</span>
                      </div>
                      <div className="relative h-2.5 bg-secondary rounded-full overflow-hidden mb-2">
                        <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }}
                          transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1], delay: i * 0.1 }}
                          className="absolute inset-y-0 left-0 rounded-full"
                          style={{ backgroundColor: g.color }} />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {g.isCompleted ? "✅ Meta concluída!" : `Faltam ${formatCurrency(remaining)} para ${formatCurrency(target)}`}
                      </p>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Budget Sheet */}
      <Sheet open={showBudgetSheet} onOpenChange={setShowBudgetSheet}>
        <SheetContent side="bottom" className="rounded-t-3xl bg-card border-border/50 max-h-[85vh] overflow-y-auto">
          <SheetHeader className="mb-4">
            <SheetTitle>{editingBudget ? "Editar Orçamento" : "Novo Orçamento"}</SheetTitle>
          </SheetHeader>
          <div className="space-y-4 pb-safe pb-6">
            <div>
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Nome</label>
              <Input value={budgetName} onChange={e => setBudgetName(e.target.value)} placeholder="Ex: Alimentação do mês" className="bg-background border-border/50 rounded-xl h-12" />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Limite (R$)</label>
              <Input type="number" value={budgetLimit} onChange={e => setBudgetLimit(e.target.value)} placeholder="0,00" className="bg-background border-border/50 rounded-xl h-12" />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Categoria (opcional)</label>
              <Select value={budgetCategoryId} onValueChange={setBudgetCategoryId}>
                <SelectTrigger className="bg-background border-border/50 rounded-xl h-12">
                  <SelectValue placeholder="Selecionar categoria" />
                </SelectTrigger>
                <SelectContent>
                  {categories.data?.filter(c => c.type === "expense" || c.type === "both").map(c => (
                    <SelectItem key={c.id} value={String(c.id)}>{getCategoryEmoji(c.icon)} {c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Alerta em ({budgetAlert}%)</label>
              <input type="range" min="50" max="100" value={budgetAlert} onChange={e => setBudgetAlert(e.target.value)}
                className="w-full accent-primary" />
            </div>
            <Button onClick={handleSaveBudget} disabled={createBudget.isPending || updateBudget.isPending}
              className="w-full h-12 rounded-2xl btn-press"
              style={{ background: "linear-gradient(135deg, oklch(0.65 0.22 295), oklch(0.55 0.22 250))" }}>
              {editingBudget ? "Salvar Alterações" : "Criar Orçamento"}
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      {/* Goal Sheet */}
      <Sheet open={showGoalSheet} onOpenChange={setShowGoalSheet}>
        <SheetContent side="bottom" className="rounded-t-3xl bg-card border-border/50 max-h-[85vh] overflow-y-auto">
          <SheetHeader className="mb-4">
            <SheetTitle>{editingGoal ? "Editar Meta" : "Nova Meta"}</SheetTitle>
          </SheetHeader>
          <div className="space-y-4 pb-safe pb-6">
            <div>
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Nome da Meta</label>
              <Input value={goalName} onChange={e => setGoalName(e.target.value)} placeholder="Ex: Viagem para Europa" className="bg-background border-border/50 rounded-xl h-12" />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Valor Alvo (R$)</label>
              <Input type="number" value={goalTarget} onChange={e => setGoalTarget(e.target.value)} placeholder="0,00" className="bg-background border-border/50 rounded-xl h-12" />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Valor Atual (R$)</label>
              <Input type="number" value={goalCurrent} onChange={e => setGoalCurrent(e.target.value)} placeholder="0,00" className="bg-background border-border/50 rounded-xl h-12" />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Prazo (opcional)</label>
              <Input type="date" value={goalDeadline} onChange={e => setGoalDeadline(e.target.value)} className="bg-background border-border/50 rounded-xl h-12" />
            </div>
            <Button onClick={handleSaveGoal} disabled={createGoal.isPending || updateGoal.isPending}
              className="w-full h-12 rounded-2xl btn-press"
              style={{ background: "linear-gradient(135deg, oklch(0.65 0.22 295), oklch(0.55 0.22 250))" }}>
              {editingGoal ? "Salvar Alterações" : "Criar Meta"}
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </AppLayout>
  );
}

function getCategoryEmoji(icon: string): string {
  const map: Record<string, string> = {
    "utensils": "🍽️", "car": "🚗", "home": "🏠", "heart": "❤️",
    "gamepad-2": "🎮", "book-open": "📚", "shopping-bag": "🛍️",
    "briefcase": "💼", "laptop": "💻", "trending-up": "📈",
    "more-horizontal": "⋯", "circle": "⭕", "target": "🎯",
  };
  return map[icon] ?? "💳";
}
