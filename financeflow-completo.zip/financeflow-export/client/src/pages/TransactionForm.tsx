import { useState, useEffect, useMemo } from "react";
import { useLocation, useParams } from "wouter";
import { motion } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { ArrowLeft, TrendingUp, TrendingDown, Calendar, Tag, FileText, Camera } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export default function TransactionForm() {
  const [, navigate] = useLocation();
  const params = useParams<{ id?: string }>();
  const isEdit = !!params.id;
  const { user, loading: authLoading } = useAuth();
  const utils = trpc.useUtils();

  const [type, setType] = useState<"income" | "expense">("expense");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [notes, setNotes] = useState("");
  const [categoryId, setCategoryId] = useState<number | undefined>();
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [receiptBase64, setReceiptBase64] = useState<string | null>(null);
  const [receiptMime, setReceiptMime] = useState("image/jpeg");

  const categories = trpc.categories.list.useQuery();
  const existingTx = trpc.transactions.get.useQuery(
    { id: Number(params.id) },
    { enabled: isEdit && !!params.id }
  );

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (existingTx.data) {
      const tx = existingTx.data;
      setType(tx.type);
      setAmount(String(tx.amount));
      setDescription(tx.description);
      setNotes(tx.notes ?? "");
      setCategoryId(tx.categoryId ?? undefined);
      setDate(new Date(tx.date).toISOString().split("T")[0]);
    }
  }, [existingTx.data]);

  const createMutation = trpc.transactions.create.useMutation({
    onSuccess: () => {
      utils.transactions.list.invalidate();
      utils.transactions.summary.invalidate();
      toast.success("Transação adicionada!");
      navigate("/transactions");
    },
    onError: (e) => toast.error("Erro: " + e.message),
  });

  const updateMutation = trpc.transactions.update.useMutation({
    onSuccess: () => {
      utils.transactions.list.invalidate();
      utils.transactions.summary.invalidate();
      toast.success("Transação atualizada!");
      navigate("/transactions");
    },
    onError: (e) => toast.error("Erro: " + e.message),
  });

  const uploadReceiptMutation = trpc.transactions.uploadReceipt.useMutation();

  const handleSubmit = async () => {
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
      toast.error("Informe um valor válido");
      return;
    }
    if (!description.trim()) {
      toast.error("Informe uma descrição");
      return;
    }

    const txDate = new Date(date + "T12:00:00");

    if (isEdit) {
      await updateMutation.mutateAsync({
        id: Number(params.id),
        type,
        amount,
        description: description.trim(),
        notes: notes.trim() || undefined,
        categoryId,
        date: txDate,
      });
    } else {
      await createMutation.mutateAsync({
        type,
        amount,
        description: description.trim(),
        notes: notes.trim() || undefined,
        categoryId,
        date: txDate,
        tags: [],
      });
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Arquivo muito grande (máx. 5MB)");
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      const base64 = result.split(",")[1];
      setReceiptBase64(base64);
      setReceiptMime(file.type);
      toast.success("Comprovante anexado!");
    };
    reader.readAsDataURL(file);
  };

  const filteredCategories = categories.data?.filter(
    (c) => c.type === type || c.type === "both"
  ) ?? [];

  const isLoading = createMutation.isPending || updateMutation.isPending;

  const formatAmountDisplay = (val: string) => {
    const num = parseFloat(val);
    if (isNaN(num)) return "";
    return num.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
  };

  return (
    <AppLayout hideNav>
      <div className="px-5 pt-safe">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3 py-5">
          <button onClick={() => navigate("/transactions")} className="w-10 h-10 rounded-xl bg-card border border-border/50 flex items-center justify-center btn-press">
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-xl font-black text-foreground">
            {isEdit ? "Editar Transação" : "Nova Transação"}
          </h1>
        </motion.div>

        {/* Type Toggle */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="flex gap-3 mb-6">
          {(["expense", "income"] as const).map((t) => (
            <button
              key={t}
              onClick={() => { setType(t); setCategoryId(undefined); }}
              className={`flex-1 flex items-center justify-center gap-2 py-3.5 rounded-2xl font-bold text-sm transition-all duration-200 btn-press ${
                type === t
                  ? t === "income"
                    ? "bg-income border-income text-income"
                    : "bg-expense border-expense text-expense"
                  : "bg-card border border-border/50 text-muted-foreground"
              }`}
            >
              {t === "income" ? <TrendingUp size={18} /> : <TrendingDown size={18} />}
              {t === "income" ? "Receita" : "Despesa"}
            </button>
          ))}
        </motion.div>

        {/* Amount */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
          className="bg-card border border-border/50 rounded-3xl p-6 mb-4 text-center">
          <p className="text-muted-foreground text-sm mb-2">Valor</p>
          <div className="flex items-center justify-center gap-2">
            <span className="text-2xl font-bold text-muted-foreground">R$</span>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0,00"
              className="text-5xl font-black text-foreground bg-transparent border-none outline-none text-center w-full tabular-nums"
              style={{ caretColor: "oklch(0.65 0.22 295)" }}
            />
          </div>
        </motion.div>

        {/* Description */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="mb-4">
          <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Descrição</label>
          <div className="relative">
            <FileText size={16} className="absolute left-3.5 top-3.5 text-muted-foreground" />
            <Input
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Ex: Almoço no restaurante"
              className="pl-10 bg-card border-border/50 rounded-xl h-12"
            />
          </div>
        </motion.div>

        {/* Category */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}
          className="mb-4">
          <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Categoria</label>
          <div className="flex gap-2 flex-wrap">
            {filteredCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setCategoryId(cat.id === categoryId ? undefined : cat.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all btn-press ${
                  categoryId === cat.id
                    ? "text-white"
                    : "bg-card border border-border/50 text-foreground"
                }`}
                style={categoryId === cat.id ? { backgroundColor: cat.color } : {}}
              >
                <span>{getCategoryEmoji(cat.icon)}</span>
                {cat.name}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Date */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="mb-4">
          <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Data</label>
          <div className="relative">
            <Calendar size={16} className="absolute left-3.5 top-3.5 text-muted-foreground" />
            <Input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="pl-10 bg-card border-border/50 rounded-xl h-12"
            />
          </div>
        </motion.div>

        {/* Notes */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}
          className="mb-4">
          <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Observações (opcional)</label>
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Adicione detalhes sobre esta transação..."
            className="bg-card border-border/50 rounded-xl resize-none"
            rows={3}
          />
        </motion.div>

        {/* Receipt Upload */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
          className="mb-6">
          <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Comprovante (opcional)</label>
          <label className={`flex items-center gap-3 p-4 rounded-xl border-2 border-dashed cursor-pointer transition-all ${
            receiptBase64 ? "border-primary bg-primary/10" : "border-border/50 bg-card"
          }`}>
            <Camera size={20} className={receiptBase64 ? "text-primary" : "text-muted-foreground"} />
            <span className={`text-sm font-medium ${receiptBase64 ? "text-primary" : "text-muted-foreground"}`}>
              {receiptBase64 ? "Comprovante anexado ✓" : "Anexar comprovante"}
            </span>
            <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
          </label>
        </motion.div>

        {/* Submit */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }}
          className="pb-safe pb-8">
          <Button
            onClick={handleSubmit}
            disabled={isLoading}
            size="lg"
            className="w-full h-14 text-base font-bold rounded-2xl btn-press"
            style={{
              background: type === "income"
                ? "linear-gradient(135deg, oklch(0.72 0.18 160), oklch(0.62 0.18 140))"
                : "linear-gradient(135deg, oklch(0.65 0.22 295), oklch(0.55 0.22 250))",
            }}
          >
            {isLoading ? "Salvando..." : isEdit ? "Salvar Alterações" : `Adicionar ${type === "income" ? "Receita" : "Despesa"}`}
          </Button>
        </motion.div>
      </div>
    </AppLayout>
  );
}

function getCategoryEmoji(icon: string): string {
  const map: Record<string, string> = {
    "utensils": "🍽️", "car": "🚗", "home": "🏠", "heart": "❤️",
    "gamepad-2": "🎮", "book-open": "📚", "shopping-bag": "🛍️",
    "briefcase": "💼", "laptop": "💻", "trending-up": "📈",
    "more-horizontal": "⋯", "circle": "⭕", "target": "🎯",
    "star": "⭐", "zap": "⚡", "coffee": "☕", "music": "🎵",
    "plane": "✈️", "gift": "🎁", "phone": "📱",
  };
  return map[icon] ?? "💳";
}
