import { useState, useEffect, useMemo } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { formatCurrency } from "@/hooks/useFinance";
import AppLayout from "@/components/AppLayout";
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend,
} from "recharts";
import { Download, FileText, FileSpreadsheet } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

const COLORS = [
  "oklch(0.65 0.22 295)",
  "oklch(0.72 0.18 160)",
  "oklch(0.62 0.22 25)",
  "oklch(0.72 0.18 220)",
  "oklch(0.72 0.18 50)",
  "oklch(0.65 0.18 320)",
  "oklch(0.72 0.18 180)",
];

function CustomPieTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="glass rounded-xl p-3 text-xs">
      <p className="font-semibold text-foreground">{payload[0].name}</p>
      <p style={{ color: payload[0].payload.fill }}>{formatCurrency(payload[0].value)}</p>
      <p className="text-muted-foreground">{payload[0].payload.pct?.toFixed(1)}%</p>
    </div>
  );
}

export default function Statistics() {
  const [, navigate] = useLocation();
  const { user, loading: authLoading } = useAuth();
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const now = new Date();
  const startDate = useMemo(() => new Date(now.getFullYear(), now.getMonth(), 1), []);
  const endDate = useMemo(() => new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59), []);

  const summary = trpc.transactions.summary.useQuery({ startDate, endDate });
  const spending = trpc.transactions.spendingByCategory.useQuery({ startDate, endDate });
  const monthly = trpc.transactions.monthlyComparison.useQuery({ months: 6 });

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  // Pie chart data
  const pieData = useMemo(() => {
    if (!spending.data) return [];
    const total = spending.data.reduce((s, c) => s + Number(c.total ?? 0), 0);
    return spending.data.map((c, i) => ({
      name: c.categoryName ?? "Outros",
      value: Number(c.total ?? 0),
      fill: c.categoryColor ?? COLORS[i % COLORS.length],
      pct: total > 0 ? (Number(c.total ?? 0) / total) * 100 : 0,
    }));
  }, [spending.data]);

  // Bar chart data
  const barData = useMemo(() => {
    if (!monthly.data) return [];
    const map: Record<string, { month: string; income: number; expense: number }> = {};
    for (const row of monthly.data) {
      const key = row.month as string;
      if (!map[key]) {
        const [year, month] = key.split("-");
        const date = new Date(Number(year), Number(month) - 1, 1);
        map[key] = {
          month: date.toLocaleDateString("pt-BR", { month: "short" }),
          income: 0,
          expense: 0,
        };
      }
      if (row.type === "income") map[key].income = Number(row.total ?? 0);
      if (row.type === "expense") map[key].expense = Number(row.total ?? 0);
    }
    return Object.values(map);
  }, [monthly.data]);

  const handleExportPDF = async () => {
    toast.info("Gerando PDF...");
    try {
      const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      const month = now.toLocaleDateString("pt-BR", { month: "long", year: "numeric" });

      // Header
      doc.setFillColor(26, 10, 46);
      doc.rect(0, 0, 210, 40, "F");
      doc.setTextColor(139, 92, 246);
      doc.setFontSize(22);
      doc.setFont("helvetica", "bold");
      doc.text("FinanceFlow", 14, 20);
      doc.setTextColor(200, 200, 200);
      doc.setFontSize(11);
      doc.setFont("helvetica", "normal");
      doc.text(`Relatório Financeiro — ${month}`, 14, 30);

      // Summary
      doc.setTextColor(30, 30, 30);
      doc.setFontSize(13);
      doc.setFont("helvetica", "bold");
      doc.text("Resumo do Período", 14, 52);
      autoTable(doc, {
        startY: 56,
        head: [["Indicador", "Valor"]],
        body: [
          ["Receitas", formatCurrency(summary.data?.income ?? 0)],
          ["Despesas", formatCurrency(summary.data?.expense ?? 0)],
          ["Saldo", formatCurrency(summary.data?.balance ?? 0)],
          ["Taxa de Poupança", summary.data?.income ? `${(((summary.data.income - summary.data.expense) / summary.data.income) * 100).toFixed(1)}%` : "—"],
        ],
        headStyles: { fillColor: [139, 92, 246], textColor: 255, fontStyle: "bold" },
        alternateRowStyles: { fillColor: [248, 245, 255] },
        styles: { fontSize: 10 },
      });

      // Spending by category
      const finalY = (doc as any).lastAutoTable?.finalY ?? 100;
      doc.setFontSize(13);
      doc.setFont("helvetica", "bold");
      doc.text("Gastos por Categoria", 14, finalY + 12);
      autoTable(doc, {
        startY: finalY + 16,
        head: [["Categoria", "Valor", "Percentual"]],
        body: pieData.map((d) => [d.name, formatCurrency(d.value), `${d.pct.toFixed(1)}%`]),
        headStyles: { fillColor: [139, 92, 246], textColor: 255, fontStyle: "bold" },
        alternateRowStyles: { fillColor: [248, 245, 255] },
        styles: { fontSize: 10 },
      });

      // Footer
      const pageCount = doc.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(150);
        doc.text(`Gerado pelo FinanceFlow em ${new Date().toLocaleString("pt-BR")} — Página ${i}/${pageCount}`, 14, 290);
      }

      doc.save(`financeflow-relatorio-${now.toISOString().split("T")[0]}.pdf`);
      toast.success("PDF exportado com sucesso!");
    } catch (e) {
      console.error(e);
      toast.error("Erro ao gerar PDF");
    }
  };

  const handleExportExcel = () => {
    toast.info("Gerando planilha Excel...");
    try {
      const wb = XLSX.utils.book_new();

      // Summary sheet
      const summaryData = [
        ["Indicador", "Valor (R$)"],
        ["Receitas", summary.data?.income ?? 0],
        ["Despesas", summary.data?.expense ?? 0],
        ["Saldo", summary.data?.balance ?? 0],
      ];
      const ws1 = XLSX.utils.aoa_to_sheet(summaryData);
      ws1["!cols"] = [{ wch: 20 }, { wch: 15 }];
      XLSX.utils.book_append_sheet(wb, ws1, "Resumo");

      // Categories sheet
      const catData = [
        ["Categoria", "Valor (R$)", "Percentual (%)"],
        ...pieData.map((d) => [d.name, d.value, d.pct.toFixed(2)]),
      ];
      const ws2 = XLSX.utils.aoa_to_sheet(catData);
      ws2["!cols"] = [{ wch: 20 }, { wch: 15 }, { wch: 15 }];
      XLSX.utils.book_append_sheet(wb, ws2, "Gastos por Categoria");

      // Monthly comparison sheet
      const monthlyData = [
        ["Mês", "Receitas (R$)", "Despesas (R$)", "Saldo (R$)"],
        ...barData.map((d) => [d.month, d.income, d.expense, d.income - d.expense]),
      ];
      const ws3 = XLSX.utils.aoa_to_sheet(monthlyData);
      ws3["!cols"] = [{ wch: 12 }, { wch: 15 }, { wch: 15 }, { wch: 15 }];
      XLSX.utils.book_append_sheet(wb, ws3, "Comparação Mensal");

      XLSX.writeFile(wb, `financeflow-${now.toISOString().split("T")[0]}.xlsx`);
      toast.success("Planilha Excel exportada!");
    } catch (e) {
      console.error(e);
      toast.error("Erro ao gerar Excel");
    }
  };

  const buildReportContent = () => {
    const month = now.toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
    return `<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="UTF-8"><title>FinanceFlow - Relatório ${month}</title>
<style>
  body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; background: #f5f5f5; }
  h1 { color: #8B5CF6; } h2 { color: #333; border-bottom: 2px solid #8B5CF6; padding-bottom: 8px; }
  .card { background: white; border-radius: 12px; padding: 20px; margin: 16px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
  .summary { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
  .metric { text-align: center; }
  .metric .value { font-size: 24px; font-weight: bold; }
  .income { color: #10B981; } .expense { color: #EF4444; } .balance { color: #8B5CF6; }
  table { width: 100%; border-collapse: collapse; }
  th, td { padding: 10px; text-align: left; border-bottom: 1px solid #eee; }
  th { background: #f9f9f9; font-weight: 600; }
</style></head>
<body>
  <h1>FinanceFlow — Relatório Financeiro</h1>
  <p>Período: ${month}</p>
  <div class="card">
    <h2>Resumo</h2>
    <div class="summary">
      <div class="metric"><div class="value income">+${formatCurrency(summary.data?.income ?? 0)}</div><div>Receitas</div></div>
      <div class="metric"><div class="value expense">-${formatCurrency(summary.data?.expense ?? 0)}</div><div>Despesas</div></div>
      <div class="metric"><div class="value balance">${formatCurrency(summary.data?.balance ?? 0)}</div><div>Saldo</div></div>
    </div>
  </div>
  <div class="card">
    <h2>Gastos por Categoria</h2>
    <table>
      <thead><tr><th>Categoria</th><th>Valor</th><th>%</th></tr></thead>
      <tbody>${pieData.map((d) => `<tr><td>${d.name}</td><td>${formatCurrency(d.value)}</td><td>${d.pct.toFixed(1)}%</td></tr>`).join("")}</tbody>
    </table>
  </div>
  <p style="color:#999;font-size:12px;text-align:center;">Gerado pelo FinanceFlow em ${new Date().toLocaleString("pt-BR")}</p>
</body></html>`;
  };

  return (
    <AppLayout>
      <div className="px-5 pt-safe">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="py-5">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-black text-foreground">Relatórios</h1>
              <p className="text-muted-foreground text-sm">
                {now.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}
              </p>
            </div>
            <div className="flex gap-2">
              <button onClick={handleExportPDF} className="w-9 h-9 rounded-xl bg-card border border-border/50 flex items-center justify-center btn-press">
                <FileText size={16} className="text-muted-foreground" />
              </button>
              <button onClick={handleExportExcel} className="w-9 h-9 rounded-xl bg-card border border-border/50 flex items-center justify-center btn-press">
                <FileSpreadsheet size={16} className="text-muted-foreground" />
              </button>
            </div>
          </div>
        </motion.div>

        {/* Summary Cards */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="grid grid-cols-3 gap-2 mb-5">
          {[
            { label: "Receitas", value: summary.data?.income ?? 0, color: "text-income" },
            { label: "Despesas", value: summary.data?.expense ?? 0, color: "text-expense" },
            { label: "Saldo", value: summary.data?.balance ?? 0, color: "text-primary" },
          ].map((item) => (
            <div key={item.label} className="bg-card border border-border/50 rounded-2xl p-3 text-center">
              <p className="text-muted-foreground text-[10px] mb-1">{item.label}</p>
              {summary.isLoading ? (
                <Skeleton className="h-4 w-16 mx-auto" />
              ) : (
                <p className={`text-xs font-bold tabular-nums ${item.color}`}>
                  {formatCurrency(item.value)}
                </p>
              )}
            </div>
          ))}
        </motion.div>

        {/* Pie Chart - Spending by Category */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="bg-card border border-border/50 rounded-3xl p-5 mb-5">
          <h2 className="text-sm font-bold text-foreground mb-4">Gastos por Categoria</h2>
          {spending.isLoading ? (
            <Skeleton className="h-48 w-full rounded-xl" />
          ) : pieData.length === 0 ? (
            <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
              Sem dados para este período
            </div>
          ) : (
            <>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={85}
                    paddingAngle={3}
                    dataKey="value"
                    onMouseEnter={(_, index) => setActiveIndex(index)}
                    onMouseLeave={() => setActiveIndex(null)}
                    animationBegin={0}
                    animationDuration={800}
                  >
                    {pieData.map((entry, index) => (
                      <Cell
                        key={index}
                        fill={entry.fill}
                        opacity={activeIndex === null || activeIndex === index ? 1 : 0.5}
                        stroke="transparent"
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomPieTooltip />} />
                </PieChart>
              </ResponsiveContainer>
              {/* Legend */}
              <div className="space-y-2 mt-3">
                {pieData.map((item, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: item.fill }} />
                      <span className="text-xs text-foreground">{item.name}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-semibold text-foreground">{formatCurrency(item.value)}</span>
                      <span className="text-xs text-muted-foreground ml-2">{item.pct.toFixed(1)}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </motion.div>

        {/* Bar Chart - Monthly Comparison */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="bg-card border border-border/50 rounded-3xl p-5 mb-6">
          <h2 className="text-sm font-bold text-foreground mb-4">Comparação Mensal</h2>
          {monthly.isLoading ? (
            <Skeleton className="h-48 w-full rounded-xl" />
          ) : barData.length === 0 ? (
            <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
              Sem dados suficientes
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={barData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 270)" />
                <XAxis dataKey="month" tick={{ fontSize: 10, fill: "oklch(0.55 0.01 270)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 9, fill: "oklch(0.55 0.01 270)" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                <Tooltip
                  formatter={(value: number) => formatCurrency(value)}
                  contentStyle={{
                    background: "oklch(0.13 0.015 270)",
                    border: "1px solid oklch(0.22 0.02 270)",
                    borderRadius: "0.75rem",
                    fontSize: "12px",
                  }}
                />
                <Bar dataKey="income" name="Receita" fill="oklch(0.72 0.18 160)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="expense" name="Despesa" fill="oklch(0.65 0.22 295)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </motion.div>

        {/* Export Buttons */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
          className="grid grid-cols-2 gap-3 mb-6">
          <Button variant="outline" onClick={handleExportPDF} className="h-12 rounded-2xl border-border/50 btn-press">
            <FileText size={16} className="mr-2" /> Exportar PDF
          </Button>
          <Button variant="outline" onClick={handleExportExcel} className="h-12 rounded-2xl border-border/50 btn-press">
            <FileSpreadsheet size={16} className="mr-2" /> Exportar CSV
          </Button>
        </motion.div>
      </div>
    </AppLayout>
  );
}
