import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { User, Mail, Shield, Bell, ChevronRight, LogOut, Settings, BarChart3, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "sonner";

export default function Profile() {
  const [, navigate] = useLocation();
  const { user, loading: authLoading, logout } = useAuth();
  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => { logout(); navigate("/login"); },
  });

  useEffect(() => {
    if (!authLoading && !user) navigate("/login");
  }, [user, authLoading, navigate]);

  const handleLogout = () => {
    if (confirm("Deseja sair da conta?")) {
      logoutMutation.mutate();
    }
  };

  const menuItems = [
    { icon: Settings, label: "Configurações", path: "/settings", color: "oklch(0.65 0.22 295)" },
    { icon: BarChart3, label: "Relatórios", path: "/statistics", color: "oklch(0.72 0.18 160)" },
    { icon: Wallet, label: "Orçamentos", path: "/budget", color: "oklch(0.72 0.18 50)" },
    { icon: Bell, label: "Notificações", path: "/settings", color: "oklch(0.72 0.18 220)" },
    { icon: Shield, label: "Segurança", path: "/settings", color: "oklch(0.62 0.22 25)" },
  ];

  const initials = user?.name
    ? user.name.split(" ").map(n => n[0]).slice(0, 2).join("").toUpperCase()
    : "U";

  return (
    <AppLayout>
      <div className="px-5 pt-safe">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="py-5">
          <h1 className="text-2xl font-black text-foreground">Perfil</h1>
        </motion.div>

        {/* Avatar & Info */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="flex flex-col items-center py-8 mb-6">
          <motion.div
            animate={{ boxShadow: ["0 0 20px oklch(0.65 0.22 295 / 0.3)", "0 0 40px oklch(0.65 0.22 295 / 0.5)", "0 0 20px oklch(0.65 0.22 295 / 0.3)"] }}
            transition={{ duration: 3, repeat: Infinity }}
            className="w-24 h-24 rounded-3xl flex items-center justify-center mb-4 text-3xl font-black text-white"
            style={{ background: "linear-gradient(135deg, oklch(0.65 0.22 295), oklch(0.55 0.22 250))" }}
          >
            {initials}
          </motion.div>
          <h2 className="text-xl font-black text-foreground">{user?.name ?? "Usuário"}</h2>
          <p className="text-muted-foreground text-sm mt-1">{user?.email ?? ""}</p>
          <div className="mt-3 px-3 py-1 rounded-full bg-primary/20 border border-primary/30">
            <span className="text-xs font-semibold text-primary">Conta Ativa</span>
          </div>
        </motion.div>

        {/* Info Cards */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="grid grid-cols-2 gap-3 mb-6">
          <div className="bg-card border border-border/50 rounded-2xl p-4 text-center">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center mx-auto mb-2">
              <User size={18} className="text-primary" />
            </div>
            <p className="text-xs text-muted-foreground">Membro desde</p>
            <p className="text-sm font-bold text-foreground mt-0.5">
              {user?.createdAt ? new Date(user.createdAt).toLocaleDateString("pt-BR", { month: "short", year: "numeric" }) : "—"}
            </p>
          </div>
          <div className="bg-card border border-border/50 rounded-2xl p-4 text-center">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center mx-auto mb-2">
              <Mail size={18} className="text-emerald-400" />
            </div>
            <p className="text-xs text-muted-foreground">Login via</p>
            <p className="text-sm font-bold text-foreground mt-0.5 capitalize">
              {user?.loginMethod ?? "Manus"}
            </p>
          </div>
        </motion.div>

        {/* Menu */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="space-y-2 mb-6">
          {menuItems.map((item, i) => (
            <motion.button
              key={item.label}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + i * 0.06 }}
              onClick={() => navigate(item.path)}
              className="w-full flex items-center gap-3 p-4 bg-card border border-border/50 rounded-2xl card-hover text-left"
            >
              <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ backgroundColor: `${item.color}20` }}>
                <item.icon size={18} style={{ color: item.color }} />
              </div>
              <span className="flex-1 text-sm font-semibold text-foreground">{item.label}</span>
              <ChevronRight size={16} className="text-muted-foreground" />
            </motion.button>
          ))}
        </motion.div>

        {/* Logout */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
          className="pb-safe pb-6">
          <Button
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
            variant="outline"
            size="lg"
            className="w-full h-14 rounded-2xl border-destructive/30 text-destructive hover:bg-destructive/10 btn-press"
          >
            <LogOut size={18} className="mr-2" />
            {logoutMutation.isPending ? "Saindo..." : "Sair da Conta"}
          </Button>
        </motion.div>
      </div>
    </AppLayout>
  );
}
